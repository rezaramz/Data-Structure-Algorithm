/**
 *
 * @author MReza
 */
public class IdComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee a, Employee b) {
        if ( a == null || b == null ) {
            throw new NullPointerException("Null object in compare method");
        }
        if ( a.getId() > b.getId() )
            return 1;
        else if ( a.getId() < b.getId() )
            return -1;
        else
            return 0;
    }
}
