/**
 * 
 * @author Mohammadreza Ramzanpour
 */
public class Sort {
	
    /** Simple bubble sort algorithm */
    public static <E> void simpleBubbleSort(E[] data, Comparator<E> comp) {
        for (int j = 0; j < data.length; j++) { 
            for (int i = 0; i < data.length - 1; i++) {
                if ( comp.compare(data[i], data[i+1]) > 0 ) {
                    E temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                }
            }
        }
    }
	
    /** Selection sort algorithm */
    public static <E> void selectionSort(E[] data, Comparator<E> comp) {
        int minIndex;
        for (int i = 0; i < data.length; i++) {
            E temp = data[i];
            minIndex = i;
            for (int j = i + 1; j < data.length; j++) {
                if ( comp.compare(data[j], temp) < 0 ) {
                    temp = data[j];
                    minIndex = j;
                }
            }
            data[minIndex] = data[i];
            data[i] = temp;
        }
    }
    
    /** Insertion sort algorithm */
    public static <E> void insertionSort(E[] data, Comparator<E> comp) {
        int j;
        E temp;
        for (int i = 1; i < data.length; i++) {
            j = i;
            temp = data[i];
            
            while ( j != 0 && comp.compare(data[j-1], temp) > 0 ) {
                data[j] = data[j - 1];
                j--;
            }
            
            data[j] = temp;
        }
    }
    
    /** Merge sort algorithm */
    public static <E> void mergeSort (E[] s, Comparator<E> comp) {
        int n = s.length;
        if ( n < 2 )
            return;
        // divide
        int mid = n / 2;
        //E[] s1 = Arrays.copyOfRange(s, 0, mid);
        E[] s1 = copyInRange(s, 0, mid);
        //E[] s2 = Arrays.copyOfRange(s, mid, n);
        E[] s2 = copyInRange(s, mid, n);
        // conquer (with recursion)
        mergeSort(s1, comp);
        mergeSort(s2, comp);
        // merge results
        merge(s1, s2, s, comp);
    }
    
    /** private utility for merging sub-arrays, used in merge sort algorithm */
    private static <E> void merge(E[] s1, E[] s2, E[] s, Comparator<E> comp) {
        int i = 0, j = 0;
        while ( i + j < s.length ) {
            if ( j == s2.length || ( i < s1.length && comp.compare(s1[i], s2[j]) < 0 ) )
                s[i + j] = s1[i++];
            else
                s[i + j] = s2[j++];
        }
    }
    
    /**
     * 
     * @param <E> generic type of data
     * @param data array we want to copy from
     * @param start starting index to copy from
     * @param end ending index to copy from
     * @return the copied array from index start to index end
     */
    private static <E> E[] copyInRange(E[] data, int start, int end) {
        E[] duplicate = (E[]) new Object[end - start];
        for (int i = 0; i < end - start; i++) {
            duplicate[i] = data[start + i];
        }
        // data = null; // Can we uncomment this line??
        return duplicate;
    }
    
    /** Recursive quick sort algorithm for sorting between two specific indexes, used as private utility */
    private static <E> void quickSortInPlace(E[] s, Comparator<E> comp, int a, int b) {
        if ( a >= b )
            return;
        int left = a;
        int right = b - 1;
        E pivot = s[b];
        E temp;
        while (left <= right) {
            while (left <= right && comp.compare(s[left], pivot) < 0)
                left++;
            while (left <= right && comp.compare(s[right], pivot) > 0)
                right--;
            if (left <= right) {
                temp = s[left];
                s[left] = s[right];
                s[right] = temp;
                left++;
                right--;
            }
        }
        temp = s[left];
        s[left] = s[b];
        s[b] = temp;
        quickSortInPlace(s, comp, a, left - 1);
        quickSortInPlace(s, comp, left + 1, b);
        
    }
    
    /** Applying recursive quick sort algorithm to the whole array */
    public static <E> void quickSort(E[] data, Comparator<E> comp) {
        quickSortInPlace(data, comp, 0, data.length - 1);
    }
    
    /** Radix sort, taking 4 comparators as input */
    public static <E> void radixSort(E[] data, Comparator<E> comp1,  Comparator<E> comp2, Comparator<E> comp3, 
            Comparator<E> comp4) {
        Sort.mergeSort(data, comp4);
        Sort.mergeSort(data, comp3);
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
    
    /** Radix sort, taking three input comparators */
    public static <E> void radixSort(E[] data, Comparator<E> comp1, Comparator<E> comp2, Comparator<E> comp3) {
        Sort.mergeSort(data, comp3);
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
    
    /** Radix sort, taking two comparators as input */
    public static <E> void radixSort(E[] data, Comparator<E> comp1, Comparator<E> comp2) {
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
	
}
