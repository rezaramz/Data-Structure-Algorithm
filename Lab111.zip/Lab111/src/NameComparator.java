/**
 *
 * @author MReza
 */
public class NameComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee a, Employee b) {
        if ( a == null || b == null ) {
            throw new NullPointerException("Null object in compare method");
        }
        int n1 = a.getName().length();
        int n2 = b.getName().length();
        int min = n1;
        if ( n2 < n1 )
            min = n2;
        for (int i = 0; i < min; i++ ) {
            int c1 = (int) a.getName().charAt(i);
            int c2 = (int) b.getName().charAt(i);
            if ( c1 > c2 )
                return 1;
            else if ( c1 < c2 )
                return -1;
        }
        if ( n1 == n2 )
            return 0;
        else if ( n1 < n2 )
            return -1;
        else
            return 1;
        /** Alternatively we can use     a.getName().compareTo(b.getName());     */
    }
}
