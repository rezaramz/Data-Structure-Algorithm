/**
 *
 * @author Mohammadreza
 */
public interface Comparator<E> {
    /**
     * 
     * @param a
     * @param b
     * @return 1 if a > b, 0 if a == b and -1 if a < b
     */
    int compare(E a, E b);
}
