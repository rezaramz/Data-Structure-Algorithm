/**
 *
 * @author MReza
 */
public class DeptComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee a, Employee b) {
        if ( a == null || b == null ) {
            throw new NullPointerException("Null object in compare method");
        }
        if ( a.getDept() > b.getDept() )
            return 1;
        else if ( a.getDept() < b.getDept() )
            return -1;
        else
            return 0;
    }
}
