import java.util.Random;
public class Employee {
    private int id;
    private String name;
    private int dept;
    private int hired;
	
    /** Default constructor, creates random attributes */
    public Employee() {
        Random rand = new Random();
        this.id = rand.nextInt(100000000);
        this.name = randomName();
        this.dept = rand.nextInt(6);
        this.hired = rand.nextInt(11) + 2008;
    }
    
    /** return id */
    public int getId() {
        return id;
    }
	
    /** return name of employee */
    public String getName() {
        return name;
    }
	
    /** return department attribute */
    public int getDept() {
        return dept;
    }
	
    /** return hired attribute */
    public int getHired() {
        return hired;
    }
    
    /** set name attribute */
    public void setName(String name) {
        this.name = name;
    }
    
    /** set id attribute */
    public void setId(int id) {
        this.id = id;
    }
    
    /** set hired attribute */
    public void setHired(int hired) {
        this.hired = hired;
    }
    
    /** set department attribute */
    public void setDept(int dept) {
        this.dept = dept;
    }
	
    /** Generate a random name 5-10 lowercase characters */
    private static String randomName() {
        Random rand = new Random();
        int numChar = 5 + rand.nextInt(6);
        String randName = "";
        for (int i = 0; i < numChar; i++) {
            int code = 97 + rand.nextInt(26); // create an integer between 97 and 123
            randName += (char) code;
        }
        return randName;
    }
    
    /** Returns string representation of Employee object */
    @Override
    public String toString() {
        String answer = "Name: " + name + " ID: " + id + " Department: " + dept + " Hired Date: " + hired;
        return answer;
    }
    
    /** Equals method for employee object. return true if equal, false otherwise */
    @Override
    public boolean equals(Object obj) {
        if ( obj instanceof Employee == false )
            return false;
        Employee e = (Employee) obj;
        return ( e.getId() == id && e.dept == dept && e.hired == hired && e.getName().equals(name) );
    }
    
    /** make a copy of Employee object */
    public static Employee copyOfEmployee(Employee emp) {
        Employee ans = new Employee();
        ans.setDept(emp.getDept());
        ans.setHired(emp.getHired());
        ans.setId(emp.getId());
        ans.setName(emp.getName());
        return ans;
    }
    
    /** make a copy out of an array of Employee objects */
    public static Employee[] copyArrayOfEmployee(Employee[] list) {
        int sz = list.length;
        Employee[] copy = new Employee[sz];
        for (int i = 0; i < sz; i++) 
            copy[i] = copyOfEmployee(list[i]);
        return copy;
    }
    
}