/**
 * 
 * @author MReza
 */
public class Client {

    public static void main(String[] args) {
        int n = 100000;
        Employee[] empList = new Employee[n];
        for (int i = 0; i < n; i++) {
            empList[i] = new Employee();
        }
        /** Creating six copies from employee list */
        Employee[] list1 = Employee.copyArrayOfEmployee(empList);
        Employee[] list2 = Employee.copyArrayOfEmployee(empList);
        Employee[] list3 = Employee.copyArrayOfEmployee(empList);
        Employee[] list4 = Employee.copyArrayOfEmployee(empList);
        Employee[] list5 = Employee.copyArrayOfEmployee(empList);
        Employee[] list6 = Employee.copyArrayOfEmployee(empList);
        
        /** Creating four comparators for sorting purpose */
        Comparator nameComp = new NameComparator();
        Comparator idComp = new IdComparator();
        Comparator hiredComp = new HiredComparator();
        Comparator deptComp = new DeptComparator();
        
        long start = System.currentTimeMillis();
        Sort.mergeSort(list1, nameComp);
        long end = System.currentTimeMillis();
        System.out.println("Time required for merge sort on name is: " + (end - start) + " ms");
        
        start = System.currentTimeMillis();
        Sort.quickSort(list2, deptComp);
        end = System.currentTimeMillis();
        System.out.println("Time required for quick sort on department is: " + (end - start) + " ms");
        
        start = System.currentTimeMillis();
        Sort.simpleBubbleSort(list3, idComp);
        end = System.currentTimeMillis();
        System.out.println("Time required for bubble sort on id is: " + (end - start) + " ms");
        
        start = System.currentTimeMillis();
        Sort.insertionSort(list4, nameComp);
        end = System.currentTimeMillis();
        System.out.println("Time required for insertion sort on name is: " + (end - start) + " ms");
        
        start = System.currentTimeMillis();
        Sort.selectionSort(list5, idComp);
        end = System.currentTimeMillis();
        System.out.println("Time required for selection sort on id is: " + (end - start) + " ms");
        
        start = System.currentTimeMillis();
        Sort.radixSort(list6, deptComp, hiredComp, nameComp);
        end = System.currentTimeMillis();
        System.out.println("Time required for radix sort on department, hired date and name is: " + (end - start) + " ms");
        
    }

}