/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class ArrayDoubleStack<E> implements DoubleStack<E> {
    private E[] data; // data is stored in this array
    private static final int CAPACITY = 50; // will be used for defining the length of the array for default constructor
    private int redIndex;
    private int blueIndex;
    /**
     * Overloaded constructor
     * @param capacity size of the storage array
     */
    public ArrayDoubleStack(int capacity) {
        data = (E[]) new Object[capacity];
        redIndex = -1;
        blueIndex = capacity;
    }
    /**
     * Default constructor which initiate an array with the length of the CAPACITY variable
     */
    public ArrayDoubleStack() {
        this(CAPACITY);
    }
    /**
     * Finds the overall size of the double stack
     * @return the summation of the number of red and blue elements
     */
    protected int size() {
        return (redSize() + blueSize());
    }
    /**
     * 
     * @return number of red elements in the double stack
     */
    @Override
    public int redSize() {
        return (redIndex + 1);
    }
    /**
     * 
     * @return number of blue elements in the double stack
     */
    @Override
    public int blueSize() {
        return (data.length - blueIndex);
    }
    /**
     * 
     * @return true if no red element exists in the double stack, false otherwise
     */
    @Override
    public boolean redIsEmpty() {
        return (redIndex == -1);
    }
    /**
     * 
     * @return true if no blue element exists in the double stack, false otherwise
     */    
    @Override
    public boolean blueIsEmpty() {
        return (blueIndex == data.length);
    }
    /**
     * inserts a red element into the double stack
     * @param e is inserted into double stack
     * @throws IllegalStateException if the array is full
     */
    @Override
    public void redPush(E e) throws IllegalStateException {
        if (size() == data.length)
            throw new IllegalStateException("Stack is full");
        data[++redIndex] = e;
    }
    /**
     * inserts a blue element into the double stack
     * @param e is inserted into double stack
     * @throws IllegalStateException if the array is full
     */
    @Override
    public void bluePush(E e) throws IllegalStateException {
        if (size() == data.length)
            throw new IllegalStateException("Stack is full");
        data[--blueIndex] = e;
    }
    /**
     * Finds the top red element in double stack
     * @return the top red element but not removes it
     */
    @Override
    public E redTop() {
        if (redIsEmpty())
            return null;
        return data[redIndex];
    }
    /**
     * Finds the top blue element in double stack
     * @return the top blue element but not removes it
     */
    @Override
    public E blueTop() {
        if (blueIsEmpty())
            return null;
        return data[blueIndex];
    }
    /**
     * Finds the top red element in the stack and removes it
     * @return the removed red element
     */
    @Override
    public E redPop() {
        E answer = redTop();
        if (answer != null)
            redIndex--;
        return answer;
    }
    /**
     * Finds the top blue element in the stack and removes it
     * @return the removed blue element
     */
    @Override
    public E bluePop() {
        E answer = blueTop();
        if (answer != null)
            blueIndex++;    
        return answer;
    }
    /**
     * String representation of the double stack
     * @return the string
     */
    @Override
    public String toString() {
        String answer = "Red Stack: ";
        for (int i = 0; i <= redIndex; i++) {
            answer += data[i].toString();
            answer += "\t";
        }
        answer += "Blue Stack: ";
        for (int i = data.length - 1; i >= blueIndex; i--) {
            answer += data[i].toString();
            answer += "\t";
        }
        return answer;
    }
    /**
     * Checks if two double stacks are equal or not
     * @param obj is checked against the ArrayDoubleStack reference variable
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if ( obj instanceof ArrayDoubleStack == false )
            return false;
        ArrayDoubleStack o = (ArrayDoubleStack) obj;
        if (o.blueSize() != blueSize())
            return false;
        if (o.redSize() != redSize())
            return false;
        for (int i = 0; i <= redIndex; i++) {
            if (data[i].equals(o.data[i]) == false)
                return false;
        }
        for (int i = data.length - 1; i >= blueIndex; i--) {
            if (data[i].equals(o.data[i]) == false)
                return false;
        }
        return true;
    }
}
