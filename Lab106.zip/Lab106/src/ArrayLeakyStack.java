/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class ArrayLeakyStack<E> implements LeakyStack<E> {
    private E[] data; // storing the data 
    private int sz; // size of the stack, number of stored elements in the stack
    private int index; // index for accessing the array
    private static final int CAPACITY = 50; // default size of the array for default constructor
    /**
     * Default constructor
     * Creates a storage array with the size of 50
     */
    public ArrayLeakyStack() {
        data = (E[]) new Object[CAPACITY];
        index = -1;
        sz = 0;
    }
    /**
     * Overloaded constructor
     * @param capacity indicates the size of array for storage of the stack
     */
    public ArrayLeakyStack(int capacity) {
        data = (E[]) new Object[capacity];
        index = -1;
        sz = 0;
    } 
    /**
     * Checks if the stack is empty or not
     * @return true if empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return (sz == 0);
    }
    /**
     * Find the size of the stack
     * @return the number of stored elements in the stack
     */
    @Override
    public int size() {
        return sz;
    }
    /**
     * Insert an element into the stack
     * @param e will be inserted into stack
     * @return the removed element in case the stack was full pre-insertion, null if stack is not full
     */
    @Override
    public E push(E e) {
        E answer = data[(index + 1) % data.length];
        data[ ++index % data.length ] = e;
        if (sz < data.length)
            sz++;
        return answer;
    }
    /**
     * Find the top element in the stack
     * @return the top element or null if empty
     */
    @Override
    public E top() {
        if (size() == 0)
            return null;
        E answer = data[index % data.length];
        return answer;
    }
    /**
     * Removes and returns the top element in the stack
     * @return null if empty, top element if not empty
     */
    @Override
    public E pop() {
        E answer = top();
        if (answer == null)
            return null;
        index--;
        sz--;
        return answer;
    }
    /**
     * Gives string representation of the stack
     * @return the string representation of its element
     */
    public String toString() {
        String answer = "";
        for (int i = 0; i < size(); i++) {
            answer += ( data[i].toString() + "\t" );
        }
        return answer;
    }
    /**
     * Check if two LeakyStack reference variables are equal or not
     * @param obj is checked against the LeakyStack reference variable
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ArrayLeakyStack == false)
            return false;
        ArrayLeakyStack als = (ArrayLeakyStack) obj;
        if (als.size() != size())
            return false;
        for (int i = 0; i < size(); i++) {
            if (als.data[i] != data[i])
                return false;
        }
        return true;
    }
}
