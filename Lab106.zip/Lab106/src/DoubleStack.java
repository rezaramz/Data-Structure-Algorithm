/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface DoubleStack<E> {
    /**
     * insert the red element to the stack
     * @param element inserted element
     */
    void redPush(E element) throws IllegalStateException;
    /**
     * Insert the blue element to the stack
     * @param element inserted element
     */
    void bluePush(E element) throws IllegalStateException;
    /**
     * Size of the red elements in the stack
     * @return number of red elements
     */
    int redSize();
    /**
     * 
     * @return the number of blue elements in the stack
     */
    int blueSize();
    /**
     * Checks if any red element exists in the stack or not
     * @return true if no red element exists, false otherwise
     */
    boolean redIsEmpty();
    /**
     * Checks if any blue element exists in the stack or not
     * @return true if no blue element exists, false otherwise
     */
    boolean blueIsEmpty();
    /**
     * 
     * @return the top red element in the stack
     */
    E redTop();
    /**
     * 
     * @return the top blue element in the stack
     */
    E blueTop();
    /**
     * Removes the top red element and returns the removed element
     * @return the removed red element
     */
    E redPop();
    /**
     * Removes the top blue element and returns the removed element
     * @return the removed blue element
     */
    E bluePop();
    /**
     * 
     * @return string representation of the double stack
     */
    @Override
    String toString();
    /**
     * Checks if two double stack are equal or not. Checks it in the term of number of red and blue elements
     * and equality of the elements stored in the stack
     * @param obj is tested for equality to the reference variable
     * @return true if equal, false otherwise
     */
    boolean equals(Object obj);
}
