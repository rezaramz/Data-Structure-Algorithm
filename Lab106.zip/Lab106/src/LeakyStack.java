/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface LeakyStack<E> {
    /**
     * Checks if the stack is empty
     * @return true if empty, false otherwise
     */
    boolean isEmpty();
    /**
     *
     * @return number of stored elements in the stack
     */
    int size();
    /**
     * Insert an element into the stack
     * @return the removed element if the stack is full
     */
    E push(E e);
    /**
     * Returns but not remove the last recent element inserted into the stack
     * @return the top element of the stack
     */
    E top();
    /**
     * Returns and remove the top element stored in the stack
     * @return the top element of the stack
     */
    E pop();
    /**
     * 
     * @return String representation of the stack
     */
    @Override
    String toString();
    /**
     * Check if two stacks are equal or not
     * @param obj
     * @return true if equal, false otherwise
     */
    @Override
    boolean equals(Object obj);
}
