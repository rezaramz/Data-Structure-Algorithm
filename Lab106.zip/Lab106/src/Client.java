/**
 * 
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        ArrayDoubleStack<Integer> obj = new ArrayDoubleStack<>(8);
        ArrayDoubleStack<Integer> obj2 = new ArrayDoubleStack<>(8);
        obj.redPush(12);
        obj.redPush(13);
        obj.redPush(14);
        obj.bluePush(9);
        obj.bluePush(6);
        obj.redPush(23);
        obj.redPush(17);
        obj.redPush(34);
        System.out.println("A blue element popped: " + obj.bluePop());
        System.out.println("A blue element popped: " + obj.bluePop());
        System.out.println("A blue element popped: " + obj.bluePop());
        obj.redPush(13);
        obj.redPush(34);
//        obj.redPush(14);
        System.out.println("A red element popped: " + obj.redPop());
        //System.out.println(obj.blueTop());
        //System.out.println(obj.blueTop());
        System.out.println("Red size: " + obj.redSize());
        System.out.println("Blue size: " + obj.blueSize());
        System.out.println("obj equals to obj2: " + obj.equals(obj2));
        System.out.println("========= End of testing DoubleStack ========");
        ////////////////////////////////////////////////////////////////////
        
        ArrayLeakyStack<Integer> als = new ArrayLeakyStack<>(4);
        System.out.println("New number pushed. Removed element is: " + als.push(12));
        System.out.println("New number pushed. Removed element is: " + als.push(13));
        System.out.println("New number pushed. Removed element is: " + als.push(24));
        System.out.println("New number pushed. Removed element is: " + als.push(67));
        System.out.println("New number pushed. Removed element is: " + als.push(34));
        System.out.println("New number pushed. Removed element is: " + als.push(11));
        System.out.println("An element popped: " + als.pop());
        System.out.println("Stack size after popping an element: " + als.size());
        System.out.println("Top element in stack: " + als.top());
        System.out.println("String representation: " + als);
        als.pop();
        als.pop();
        System.out.println("Is stack empty after 2 popping? " + als.isEmpty());
        System.out.println("========= End of testing LeakyStack ========");
    }
    
}