import java.util.Random;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Client {
    public static void main(String[] args) {
        int rand;
        Random randObj = new Random();
        Scores numList = new Scores(100);
        
        //Assigning random values between -100 to 100 to the created bag
        for (int i = 0; i < 100; i++) {
            rand = randObj.nextInt(201) - 100; //Create numbers in the range of -100 to 100
            numList.add(rand);
        }
        //Printing the string details of the created bag
        System.out.println(numList.toString());
        //Add number 86 to the list
        numList.add(86);
        System.out.println("Number 86 successfully added to the bag.");
        //Printing the current size of the bag
        System.out.println("Count of the numbers in the bag is: " + numList.getCurrentSize());
        //Removing a number from random index from the bag
        numList.remove();
        System.out.println("A number in random index was removed.");
        int temp = numList.get(75);
        //Finding the frequency of the 75th number in the bag
        System.out.println("The frequency of the number at index 75 occurring in bag is: "
            + numList.getFrequencyOf(temp));
        //Remove the first occurrence of the number at 75th index from the bag
        numList.remove(temp);
        //Printing the frequency of the aforementioned number after removing its first occurrence
        System.out.println("The frequency of the number at index 75 after removing its first occurrence in bag is: "
            + numList.getFrequencyOf(temp));
        //Find the occurrence frequency of number 86 in the bag
        System.out.println("The frequency of the number 86 occurring in bag is: " + numList.getFrequencyOf(86));
        //Check the contains method by applying it on number 86 in the bag
        System.out.println("Is there a number 86 in the bag? " + numList.contains(86));
    }
    
}
