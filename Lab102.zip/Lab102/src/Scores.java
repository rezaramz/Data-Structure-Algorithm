import java.util.Random;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Scores implements Bag {
    /**
     * Array variable for storing the integers number
     */
    private int[] list;
    /**
     * Count of the numbers currently stored in the bag
     */
    private int count;
    
    /**
     * Default constructor, create a list with the length of 50
     */
    public Scores() {
        this.list = new int[50];
        this.count = 0;
    }
    /**
     * Overload constructor, create an array with the length of initialArrayLength
     * @param initialArrayLength 
     */
    public Scores(int initialArrayLength) {
        this.list = new int[initialArrayLength];
        this.count = 0;
    }
    
    /**
     * Obtain number of integers stored
     * @return Current size of the bag
     */
    @Override
    public int getCurrentSize() {return count;}
    /**
     * Checks if the bag is empty or not
     * @return true if empty, false otherwise
     */
    @Override
    public boolean isEmpty() {return count == 0;}
    /**
     * Clears all the integer number from the bag
     */
    @Override
    public void clear() {this.count = 0;}
    /**
     * Adds integer number to the end of the list of the bag
     * @param num 
     */
    @Override
    public void add(int num) {
        int[] temp;
        if (this.count == list.length) {
            temp = new int[2 * count];
            for (int i = 0; i < count; i++)
                temp[i] = list[i];
            list = temp;
            temp = null;
            list[this.count] = num;
            this.count = this.count + 1;
        }
        else {
            list[this.count] = num;
            this.count = this.count + 1;
            //list[count++] = num;
        }
    }
    /**
     * Obtain number of occurrence of a number
     * @param num
     * @return the number of occurrence of a number in the bag
     */
    @Override
    public int getFrequencyOf(int num) {
        int numberOfOccurrence = 0;
        for (int i = 0; i < count; i++) {
            if (list[i] == num)
                numberOfOccurrence++;
        }
        return numberOfOccurrence;
    }
    /**
     * Checks if a specific number exists in the bag or not
     * @param num
     * @return true if the number is in the bag, false otherwise
     */
    @Override
    public boolean contains(int num) {
        boolean isOccurrence = false;
        for (int i = 0; i < count; i++) {
            if (list[i] == num) {
                isOccurrence = true;
                break;
            }
        }
        return isOccurrence;
    }
    /**
     * Removes the first occurrence of a specific number in the bag/ shifts the remaining numbers to the left
     * @param num 
     */
    @Override
    public void remove(int num) {
        int placeOfOccurrence = count;
        //int[] temp = new int[count];
        for (int i = 0; i < count; i++) {
            if (list[i] == num) {
                placeOfOccurrence = i;
                break;
            }
        }
        if (placeOfOccurrence < count) {
            for (int i = placeOfOccurrence; i < count; i++) {
                list[i] = list[i+1];
            }
            count--;
        }
    }
    /**
     * Removes a random number from the bag
     */
    @Override
    public void remove() {
        if (count != 0) {
            Random randObj = new Random();
            int randIndex = randObj.nextInt(count);
            for (int i = randIndex; i < count; i++) {
                list[i] = list[i+1];
            }
            count--;
        }
    }
    /**
     * String detail output of the bag
     * @return The string details of the numbers stored in the bag
     */
    @Override
    public String toString() {
        String temp;
        if (count == 0)
            return "The bag is empty";
        temp = "[";
        for (int i = 0; i < count; i++) {
            temp = temp + list[i];
            if (i != count - 1)
                temp = temp + ", ";
        }
        temp = temp + "]";
        return temp;
    }
    /**
     * Check if two bag lists are equivalent to each other or not in terms of numbers stored and order of them
     * @param obj
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Scores == false)
            return false;
        Scores o = (Scores) obj;
        if (count != o.getCurrentSize())
            return false;
        for (int i = 0; i < count; i++) {
            if (o.get(i) != list[i])
                return false;
        }
        return true;
    }
    /**
     * Find the stored number value at a specific index
     * @param index
     * @return The integer value of the bag list at a specific index
     */
    public int get(int index) throws ArrayIndexOutOfBoundsException{
        if ( index >= 0 && index <= (count - 1))
            return list[index];
        else
            throw new ArrayIndexOutOfBoundsException("Selected index is out of bounds.");
    }
    
}