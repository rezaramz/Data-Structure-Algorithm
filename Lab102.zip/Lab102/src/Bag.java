/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface Bag {
    /**
     * 
     * @return a count of numbers in the bag
     */
    public int getCurrentSize();
    /**
     * checks if the Bag is empty
     * @return true if empty
     */
    public boolean isEmpty();
    /**
     * Add the number num into the Bag
     * @param num 
     */
    public void add(int num);
    /**
     * removes the first occurrence of the number num from the Bag
     * @param num 
     */
    public void remove(int num);
    /**
     * Removes a randomly selected entry from the bag
     */
    public void remove();
    /**
     * removes all the numbers from the Bag
     */
    public void clear();
    /**
     * 
     * @param num
     * @return a count the number of the times the number num exists in the bag
     */
    public int getFrequencyOf(int num);
    /**
     * Tests whether the bag contains the number num
     * @param num
     * @return true if exist, false otherwise
     */
    public boolean contains(int num);
    /**
     * 
     * @return String contents of the Bag
     */
    @Override
    public String toString();
    /**
     * 
     * @param o
     * @return true if the the parameter o exactly matches the contents of the Bag
     */
    @Override
    public boolean equals(Object o);
}
