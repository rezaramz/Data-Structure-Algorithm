import java.util.Scanner;
/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        String name, positionPlayed;
        int jerseyNumber;
        Player p;
        Scanner input = new Scanner(System.in);
        ArrayBag<Player> footballTeam = new ArrayBag<>(2);
        int initialNumberOfPlayers;
        System.out.print("Enter initial number of football team players: ");
        initialNumberOfPlayers = input.nextInt();
        for (int i = 0; i < initialNumberOfPlayers; i++) {
            System.out.print("Enter name of a player: ");
            name = input.next();
            System.out.print("Enter position of player: ");
            positionPlayed = input.next();
            System.out.print("Enter Jersey number of player: ");
            jerseyNumber = input.nextInt();
            p = new Player(name, positionPlayed, jerseyNumber);
            footballTeam.add(p);
        }
        System.out.println("Football team detail: " + footballTeam);
        footballTeam.remove();
        System.out.println("Football team detail after random player removed: " + footballTeam);
        
        System.out.print("Enter new player name: ");
        name = input.next();
        System.out.print("Enter position of the new player: ");
        positionPlayed = input.next();
        System.out.print("Enter Jersey number of the new player: ");
        jerseyNumber = input.nextInt();
        p = new Player(name, positionPlayed, jerseyNumber);
        
        footballTeam.add(p);
        System.out.println("Football team detail after entering the new player: " + footballTeam);
        
        footballTeam.remove(p);
        System.out.println("Football team detail after removing the most recent entry: " + footballTeam);
        System.out.println("******* Football team operations finished *******");
        
        Bag courses;
        courses = new ArrayBag<>(2);
        courses.add("CSCI161");
        courses.add("ME722");
        courses.add("ME729");
        courses.add("CSCI765");
        System.out.println("List of the courses taken this semester: " + courses);
        courses.remove();
        System.out.println("List of courses after removing a random one: " + courses);
        System.out.println("******* Courses operations finished *******");
        
        LinkedBag<Player> basketballTeam = new LinkedBag<>();
        System.out.print("Enter initial number of basketball team players: ");
        initialNumberOfPlayers = input.nextInt();
        for (int i = 0; i < initialNumberOfPlayers; i++) {
            System.out.print("Enter name of a player: ");
            name = input.next();
            System.out.print("Enter player position: ");
            positionPlayed = input.next();
            System.out.print("Enter player jersey number: ");
            jerseyNumber = input.nextInt();
            p = new Player(name, positionPlayed, jerseyNumber);
            basketballTeam.add(p);
        }

        System.out.println("Basketball team detail: " + basketballTeam);
        basketballTeam.remove();
        System.out.println("Basketball team detail after removing a random player: " + basketballTeam);
        
        System.out.print("Enter new player name: ");
        name = input.next();
        System.out.print("Enter position of the new player: ");
        positionPlayed = input.next();
        System.out.print("Enter Jersey number of the new player: ");
        jerseyNumber = input.nextInt();
        p = new Player(name, positionPlayed, jerseyNumber);
        basketballTeam.add(p);
        System.out.println("The basketball team detail after adding the new player: " + basketballTeam);
        
        basketballTeam.remove(p);
        System.out.println("Basketball team detail after removing the most recent entry: " + basketballTeam);
        System.out.println("******* Basketball team operations finished *******");
    }
}