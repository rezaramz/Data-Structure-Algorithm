/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 * @param <A> placeholder for generic type 
 */
public interface Bag<A> {
    /**
     * Find the size of a list of objects
     * @return size of the list
     */
    int getCurrentSize();
    /**
     * Check if the list is empty or not
     * @return true if empty, false otherwise
     */
    boolean isEmpty();
    /**
     * Adds an element into the list
     * @param item will be added 
     */
    void add(A item);
    /**
     * Removes a random item from the list
     * @return the removed item
     */
    A remove();
    /**
     * removes a specific item from the list
     * @param item will be remove
     * @return true if the item is found in the list and will be deleted, false otherwise
     */
    boolean remove(A item);
    /**
     * clears all the elements from the list
     */
    void clear();
    /**
     * Find the frequency of occurrence of an item in the list
     * @param item will be checked to find its frequency
     * @return the number of occurrence of an item in the list
     */
    int getFrequencyOf(A item);
    /**
     * Check if the list has a specific item or not
     * @param item
     * @return true if item exists in the list, false otherwise
     */
    boolean contains(A item);
    /**
     * String detail of the list
     * @return String details
     */
    @Override
    String toString();
    /**
     * Checks if two objects are equal or not
     * @param obj will be checked for equality constraint
     * @return true if equal, false otherwise
     */
    @Override
    boolean equals(Object obj);
}
