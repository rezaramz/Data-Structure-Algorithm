/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 */
public class Player {
    String name;
    String positionPlayed;
    int jerseyNumber;
    /**
     * Overloaded Constructor
     * @param name name of the player.
     * @param positionPlayed The position that a player plays in.
     * @param jerseyNumber Jersey number of the player.
     */
    public Player(String name, String positionPlayed, int jerseyNumber) {
        this.name = name;
        this.positionPlayed = positionPlayed;
        this.jerseyNumber = jerseyNumber;
    }
    //Getter methods
    /**
     * Gets the name of a player
     * @return String name of the player.
     */
    public String getName() {return name;}
    /**
     * Get the position of a player
     * @return the position a player plays in. 
     */
    public String getPositionPlayed() {return positionPlayed;}
    /**
     * Get the jersey number of a player.
     * @return the String jersey number.
     */
    public int getJerseyNumber() {return jerseyNumber;}
    //Setter methods
    /**
     * Sets the name of a player.
     * @param name will be set as the name.
     */
    public void setName(String name) {this.name = name;}
    /**
     * Sets the position of a player.
     * @param positionPlayed will be set as a position of a player.
     */
    public void setPositionPlayed(String positionPlayed) {this.positionPlayed = positionPlayed;}
    /**
     * Sets the jersey number of a player.
     * @param jerseyNumber will be set as jersey number.
     */
    public void setJerseyNumber(int jerseyNumber) {this.jerseyNumber = jerseyNumber;}
    
    public String toString() {
        return "\tName: " + name + "\tPosition: " + positionPlayed + "\tJersey: " + jerseyNumber; 
    }
    
    public boolean equals(Object obj) {
        if (obj instanceof Player == false)
            return false;
        Player p = (Player) obj;
        return (name.equals(p.name) && positionPlayed.equals(p.positionPlayed)
                && jerseyNumber == p.jerseyNumber);
    }
}
