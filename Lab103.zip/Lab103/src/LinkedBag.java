import java.util.Random;
/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 * @param <T>
 */
public class LinkedBag<T> implements Bag<T>{
    private SinglyLinkedList list;
    private int count;
    /**
     * Default constructor, creates an empty singly linked list structure.
     */
    public LinkedBag() {
        list = new SinglyLinkedList();
        //count = list.size();
        count = 0;
    }
    /**
     * Gets the current size of the SLL.
     * @return The number of valid items stored in the SLL.
     */
    @Override
    public int getCurrentSize() {return count;}
    /**
     * Checks if the SLL is empty or not.
     * @return true if empty, false otherwise.
     */
    @Override
    public boolean isEmpty() {return count == 0;}
    /**
     * Adds an element into the SLL.
     * @param item will be added to the end of the SLL.
     */
    @Override
    public void add(T item) {
        list.addLast(item);
        count++;
    }
    /**
     * Removes a random element from the SLL.
     * @return the removed element if any, null if the list is empty.
     */
    @Override
    public T remove() {
        T temp;
        if (list.isEmpty())
            return null;
        Random randObj = new Random();
        int randIndex = randObj.nextInt(list.size());
        rotate(randIndex);
        temp = (T) list.removeFirst();
        rotate(count - randIndex - 1); //Bring back to the initial state 
        count--;
        return temp;
    }
    /**
     * Removes a specific item from the SLL.
     * @param item will be checked for existing and removing
     * @return true if the item exists and being removed, false otherwise.
     */
    @Override
    public boolean remove(T item) {
        int placeOfOccurrence = count;
        for (int i = 0; i < count; i++) {
            if (get(i).equals(item)) {
                placeOfOccurrence = i;
                break;
            }
        }
        if (placeOfOccurrence != count) {
            rotate(placeOfOccurrence);
            list.removeFirst();
            rotate(count - placeOfOccurrence - 1);
            count--;
            return true;
        }
        return false;
    }
    /**
     * Clear all the contents from the SLL, SLL will be empty after applying.
     */
    @Override
    public void clear() {
        //list = null;
        this.list = new SinglyLinkedList();
        count = 0;
    }
    /**
     * Checks if an item exists in the SLL or not.
     * @param item will be checked 
     * @return true if contains the item, false otherwise.
     */
    @Override
    public boolean contains(T item) {
        for (int i = 0; i < count; i++) {
            if (get(i).equals(item))
                return true;
        }
        return false;
    }
    /**
     * Occurrence frequency of an item in the SLL.
     * @param item will be checked for frequency
     * @return number of occurrence of an item in the SLL.
     */
    @Override
    public int getFrequencyOf(T item) {
        int freq = 0;
        for (int i = 0; i < count; i++) {
            if (get(i).equals(item))
                freq++;
        }
        return freq;
    }
    /**
     * String details
     * @return String details
     */
    @Override
    public String toString() {
        String temp = "[ ";
        for (int i = 0; i < count; i++) {
            temp += get(i).toString();
            if (i != count - 1)
                temp += ", ";
        }
        temp += " ]";
        return temp;
    }
    /**
     * Check if an instance of a LinkedBag class is equal to some object
     * @param obj will be checked against an instance of LinkedBag class.
     * @return true if equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof LinkedBag == false)
            return false;
        T o = (T) obj;
        for (int i = 0; i < count; i++) {
            if (get(i).equals(o) == false)
                return false;
        }
        return true;
    }
    /**
     * Several Rotation of a SLL by moving the placing the head element in the end of the SLL
     * @param numRotation number of rotations performed on the SLL.
     */
    //Additional methods created
    private void rotate(int numRotation) {
        T temp;
        for (int i = 0; i < numRotation; i++) {
            temp = (T) list.removeFirst();
            list.addLast(temp);
        }
    }
    /**
     * returns an element from a specific index of SLL.
     * @param index the index desired its element to be removed.
     * @return The element stored at index "index" and will be removed.
     */
    private T get(int index) throws ArrayIndexOutOfBoundsException {
        if (index < 0 || index > count - 1)
            throw new ArrayIndexOutOfBoundsException();
        rotate(index);
        T temp;
        temp = (T) list.first();
        rotate(count - index); //To bring it to the initial state // count - index + index = count;
        return temp;
    }
}
