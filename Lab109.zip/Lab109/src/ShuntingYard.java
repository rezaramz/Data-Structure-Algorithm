/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class ShuntingYard {
    
    /** Converting infix Queue to postfix */
    public static LinkedQueue<String> infixToPostfix(LinkedQueue<String> expression)  throws IllegalArgumentException {
        String temp, temp2;
        LinkedStack<String> operators = new LinkedStack<>();
        LinkedQueue<String> numbers = new LinkedQueue<>();
        
        int sz = expression.size();
        for (int i = 0; i < sz; i++) {
            if ( isNumber(expression.first()) ) {
                temp = expression.dequeue();
                numbers.enqueue(temp);
            }
            else if ( isOperator( expression.first() ) ) {
                boolean check = isValidPrecedence(expression, operators);
                if (check) {
                    temp = expression.dequeue();
                    operators.push(temp);
                }
                else {
                    while ( !isValidPrecedence(expression, operators) ) {
                        numbers.enqueue(operators.pop());
                    }
                    operators.push(expression.dequeue());
                }
            }
            else if ( isLeftGrouper( expression.first() ) ) {
                temp = expression.dequeue();
                operators.push(temp);
            }
            else if (isRightGrouper(expression.first())) {
                //temp2 = expression.dequeue();
                temp2 = expression.first();
                while( !isLeftGrouper(operators.top()) ) {
                    temp = operators.pop();
                    numbers.enqueue(temp);
                    if (operators.isEmpty())
                        break;
                }
                if (operators.isEmpty() && !expression.isEmpty())
                    throw new IllegalArgumentException("Invalid Expression");
                //The stack is reached to the left pranthesese at this point
                if (grouperMatch(temp2, operators.top())) // check if both are () or {} or []
                    operators.pop();
                else
                    throw new IllegalArgumentException("Invalid expression");
                expression.dequeue();
            }
            else {
                throw new IllegalArgumentException("Invalid Expression");
            }
        }
        /** Check if there is a grouper left in the stack
        /** Transfer whatever left in the stack to the numbers */
        sz = operators.size();
        for (int i = 0; i < sz; i++) {
            temp = operators.pop();
            if (isLeftGrouper(temp))
                throw new IllegalArgumentException("Invalid Expression");
            numbers.enqueue(temp);
        }
        return numbers;
    }
    
    /** Calculate the result for postfix Queue */
    public static double calculate (LinkedQueue<String> numbers) throws IllegalArgumentException {
        LinkedStack<LinkedBinaryTree<String>> mathStack = new LinkedStack<>();
        LinkedBinaryTree<String> t1, tR, tL;
        Position<String> pos;
        double ans;
        String temp;
        int sz = numbers.size();
        for (int i = 0; i < sz; i++) {
            if (isNumber(numbers.first())) {
                temp = numbers.dequeue();
                t1 = new LinkedBinaryTree<>();
                t1.addRoot(temp);
                mathStack.push(t1);
            }
            else if (isOperator(numbers.first())) {
                temp = numbers.dequeue();
                t1 = new LinkedBinaryTree<>();
                pos = t1.addRoot(temp);
                tR = mathStack.pop();
                tL = mathStack.pop();
                if (tR == null || tL == null)
                    throw new IllegalArgumentException("Invalid Expression");
                t1.attach(pos, tL, tR);
                ans = calculateTree(t1);
                temp = String.valueOf(ans);
                t1 = new LinkedBinaryTree<>();
                t1.addRoot(temp);
                mathStack.push(t1);
            }
        }
        
        t1 = mathStack.top();
        return Double.parseDouble(t1.root().getElement());
    }
    
    /** Create arithmetic binary tree from postfix expression */
    public static LinkedBinaryTree<String> createTree (LinkedQueue<String> numbers) throws IllegalArgumentException {
        
        LinkedStack<LinkedBinaryTree<String>> mathStack = new LinkedStack<>();
        LinkedBinaryTree<String> t1, tR, tL;
        Position<String> pos;
        String temp;
        int sz = numbers.size();
        for (int i = 0; i < sz; i++) {
            if (isNumber(numbers.first())) {
                temp = numbers.dequeue();
                t1 = new LinkedBinaryTree<>();
                t1.addRoot(temp);
                mathStack.push(t1);
            }
            else if (isOperator(numbers.first())) {
                temp = numbers.dequeue();
                t1 = new LinkedBinaryTree<>();
                pos = t1.addRoot(temp);
                tR = mathStack.pop();
                tL = mathStack.pop();
                if (tR == null || tL == null)
                    throw new IllegalArgumentException("Invalid Expression");
                t1.attach(pos, tL, tR);
                mathStack.push(t1);
            }
        }
        return mathStack.top();
    }
    
    /** private utility for calculating addition, subtraction, multiplication and division from a binary tree */
    private static double calculateTree(LinkedBinaryTree<String> t) throws IllegalArgumentException {
        double rightOp, leftOp;
        Position<String> rootPos = t.root();
        
        switch (t.root().getElement()) {
            case "*":
                leftOp = Double.parseDouble(t.left(rootPos).getElement());
                rightOp = Double.parseDouble(t.right(rootPos).getElement());
                return (leftOp * rightOp);
            case "/":
                leftOp = Double.parseDouble(t.left(rootPos).getElement());
                rightOp = Double.parseDouble(t.right(rootPos).getElement());
                return (leftOp / rightOp);
            case "+":
                leftOp = Double.parseDouble(t.left(rootPos).getElement());
                rightOp = Double.parseDouble(t.right(rootPos).getElement());
                return (leftOp + rightOp);
            case "-":
                leftOp = Double.parseDouble(t.left(rootPos).getElement());
                rightOp = Double.parseDouble(t.right(rootPos).getElement());
                return (leftOp - rightOp);
            default:
                throw new IllegalArgumentException("Invalid Expression");
        }
    }
    
    /** Checks if the grouper match together or not. returns true if match, false otherwise */
    private static boolean grouperMatch(String s1, String s2) {
        switch (s1) {
            case "(":
                return s2.equals(")");
            case ")":
                return s2.equals("(");
            case "{":
                return s2.equals("}");
            case "}":
                return s2.equals("{");
            case "[":
                return s2.equals("]");
            case "]":
                return s2.equals("[");
        }
        return false; // Never reaches here
    }
    
    /** Make a deep copy of a LinkedQueue storing String elements */
    public static LinkedQueue<String> copyLinkedQueue(LinkedQueue<String> lq) {
        String temp;
        int sz = lq.size();
        LinkedQueue<String> copy = new LinkedQueue<>();
        
        for (int i = 0; i < sz; i++) {
            temp = lq.dequeue();
            lq.enqueue(temp);
            copy.enqueue(temp);
        }
        return copy;
    }
    
    /** Private utility to check if / or * can be pushed in the stack or not */
    private static boolean isValidPrecedence (LinkedQueue<String> qu, LinkedStack<String> st) {
        String quFirst = qu.first();
        String stTop = st.top();
        if (stTop == null)
            return true;
        if ( quFirst.equals("+") || quFirst.equals("-") ) {
            if ( stTop.equals("/") || stTop.equals("*") )
                return false;
        }
        return true;
    }
    
    /** Checks if a String can be cast into Double value or not. True if can, false otherwise */
    private static boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException nfe) {
            return false;
        }
    }
    
    /** Checks if a String is * , / , + or - */
    private static boolean isOperator(String s) {
        return (s.equals("*") || s.equals("/") || s.equals("+") || s.equals("-"));
    }

    /** Checks if String is equal to ( , [ or { */
    private static boolean isLeftGrouper(String s) {
        return ( s.equals("(") || s.equals("[") || s.equals("{") );
    }
    
    /** Checks if a String is equal to ) , ] , } */
    private static boolean isRightGrouper(String s) {
        return ( s.equals(")") || s.equals("]") || s.equals("}") );
    }
    
    /** Checks if a LinkedQueue of postfix expression is valid or not */
    /** This is done by converting it to postfix and creating its binary arithmetic tree */
    /** If no exception throwed, true will be returned. false otherwise */
    public static boolean isValidExpression(LinkedQueue<String> lq) {
        LinkedQueue<String> lqCopy = copyLinkedQueue(lq);
        try {
            LinkedQueue<String> post = ShuntingYard.infixToPostfix(lqCopy);
            createTree(post);
        }
        catch (IllegalArgumentException iae ) {
            return false;
        }
        return true;
    }
    
}
