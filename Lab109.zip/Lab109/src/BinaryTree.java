/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface BinaryTree<E> extends Tree<E> {
    /** Return the position of p's left child */
    Position<E> left(Position<E> p) throws IllegalArgumentException;
    /** Return the position of p's right child */
    Position<E> right(Position<E> p) throws IllegalArgumentException;
    /** Returns the position of p's siblings (or null if no sibling exists) */
    Position<E> sibling(Position<E> p) throws IllegalArgumentException;
}
