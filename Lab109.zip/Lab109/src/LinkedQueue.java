/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class LinkedQueue<E> implements Queue<E> {
    private SinglyLinkedList<E> list = new SinglyLinkedList<>(); // instance variable of LinkedQueue
    /**
     * default constructor. creates an empty queue with a SinglyLinkedList container
     */
    public LinkedQueue() {}
    /** Returns the number of elements in the Queue */
    @Override
    public int size() {return list.size();}
    /** Checks if the queue is empty or not. True if empty, false otherwise */
    @Override
    public boolean isEmpty() {return list.isEmpty();}
    /** Insert an element into the queue */
    @Override
    public void enqueue(E element) {list.addLast(element);}
    /** Returns the first element of the queue */
    @Override
    public E first() {return list.first();}
    /** remove the first element of the queue and returns its value */
    @Override
    public E dequeue() {return list.removeFirst();}
    
}
