/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 * @param <E>
 */
public class SinglyLinkedList<E> {
    /**
     * Nested class for creating nodes of the singly linked list structure
     * @param <E> 
     */
    //---------- Nested Node class ----------
    private static class Node<E> {
        private E element;
        private Node<E> next;
        /**
         * Overloaded constructor, creates a node with the element and next pointing to the next node.
         * @param element
         * @param next 
         */
        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }
        /**
         * Obtain the element of a node
         * @return the element stored in the node
         */
        public E getElement() {return element;}
        /**
         * Finds the node which the called node points to.
         * @return the next node.
         */
        public Node<E> getNext() {return next;}
        /**
         * set the next part of a node
         * @param n Node "n" will be assigned to the next part of node.
         */
        public void setNext(Node<E> n) {next = n;}
    } //---------- end of nested Node class ----------
    
    private Node<E> head = null;
    private Node<E> tail = null;
    private int size = 0;
    /**
     * Default constructor which creates an empty singly linked list
     */
    public SinglyLinkedList() {}
    // access methods
    /**
     * Finds the number of nodes stored in the singly linked list.
     * @return the number of nodes in the list.
     */
    public int size() {return size;}
    /**
     * Checks if the SLList is empty or not.
     * @return true if the list is empty, false otherwise.
     */
    public boolean isEmpty() {return size == 0;}
    /**
     * Find the first element of the SLList.
     * @return the first element which is actually stored in the first node of the list.
     */
    public E first() {
        if (isEmpty())
            return null;
        return head.getElement();
    }
    /**
     * Find the last element of the SLList.
     * @return the last element which is stored in the last node of the list.
     */
    public E last() {
        if (isEmpty())
            return null;
        return tail.getElement();
    }
    /**
     * Adds an element to the front(beginning) of the list.
     * @param e element "e" will be store in the new node and placed at the front of the list set as head.
     */
    // update methods
    public void addFirst(E e) {
        head = new Node<>(e, head);
        if (size == 0)
            tail = head;
        size++;
    }
    /**
     * Adds an element to the end of the list
     * @param e element "e" will  be added to the end of the list stored in a new node set as tail.
     */
    public void addLast(E e) {
        Node<E> newest = new Node<>(e, null);
        if (isEmpty())
            head = newest;
        else
            tail.setNext(newest);
        tail = newest;
        size++;
    }
    /**
     * Removes the first element from the list.
     * @return the removed first element from the head of the list.
     */
    public E removeFirst() {
        if (isEmpty())
            return null;
        E answer = head.getElement();
        head = head.getNext();
        size--;
        if (size == 0)
            tail = null;
        return answer;
    }
}