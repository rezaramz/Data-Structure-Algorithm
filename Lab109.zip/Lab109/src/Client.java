import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        
        ArrayList<LinkedQueue<String>> expression = new ArrayList<>();
        ArrayList<String> text = new ArrayList<>();
        String address = JOptionPane.showInputDialog(null, "Enter the address of your text file:");
        System.out.println("Displaying and evaluating the content of the text file at " + address);
        System.out.println("**********************************");
        File file = new File(address);
        int count = 0;
        try {
            String temp;
            Scanner sc = new Scanner(file);
            while(sc.hasNextLine()) {
                temp = sc.nextLine();
                text.add(count, temp);
                LinkedQueue<String> context = new LinkedQueue<>();
                for ( String token : temp.split(" ") ) {
                    context.enqueue(token);
                }
                expression.add(count++, context);
                context = null;
            }
        }
        catch (FileNotFoundException fnfe) {
            System.out.println("File not found");
        }
        
//        System.out.println(expression.get(0).dequeue());
//        System.out.println(expression.get(0).dequeue());
//        System.out.println(expression.get(0).dequeue());
//        System.out.println(ShuntingYard.isOperator("+-3"));
//        System.exit(0);
        
        try {
            int sz = expression.size();
            for (int i = 0; i < sz; i++) {
                /** Showing the read expression from the text file */
                System.out.println("Expression:");
                System.out.println(text.get(i));
                if (ShuntingYard.isValidExpression(expression.get(i)))
                    System.out.println("The above expression is valid.");
                else {
                    System.out.println("The above expression is NOT valid");
                    System.out.println("===============================");
                    continue;
                }
                /** Convert infix to postfix */
                // Have to check for the nummber of groupers ( 2 left --- 2 right )
                LinkedQueue<String> postfix = ShuntingYard.infixToPostfix(expression.get(i));
                /** Copy the infix */
                LinkedQueue<String> postfixCopy = ShuntingYard.copyLinkedQueue(postfix);
                System.out.println("The result of the expression:");
                /** Calculate the result */
                System.out.println(ShuntingYard.calculate(postfixCopy));
                /** Create an arithmetic binary tree from postfix statement */
                LinkedBinaryTree<String> mathTree = ShuntingYard.createTree(postfix);
                /** Print Eulers tour presentation */
                System.out.println("Eulers tour presentation:");
                mathTree.printInorder(mathTree.root());
                System.out.println();
                // * * * * * * * *
                // Pre-order print
                System.out.println("Pre-order traversal:");
                Iterator<Position<String>> it = mathTree.preorder().iterator();
                while (it.hasNext())
                    System.out.print(it.next().getElement() + " ");
                System.out.println();
                // Post-order print
                System.out.println("Post-order traversal:");
                it = mathTree.postorder().iterator();
                while (it.hasNext())
                    System.out.print(it.next().getElement() + " ");
                System.out.println();
                // In-order print
                System.out.println("In-Order traversal:");
                it = mathTree.inorder().iterator();
                while (it.hasNext())
                    System.out.print(it.next().getElement() + " ");
                System.out.println();
                System.out.println("===============================");
            }
        }
        catch (IllegalArgumentException iae) {
            System.out.println(iae.getMessage());
        }
    }
    
}
