/**
 *
 * @author MReza
 */
public class TwoValue {
    int first;
    int second;
    /**
     * Default constructor that creates paired values stored in one object
     */
    public TwoValue() {
        first = 0;
        second = 0;
    }
    /**
     * Set the first item value 
     * @param first will be set as the first integer value
     */
    public void setFirst(int first) {
        this.first = first;
    }
    /**
     * Set the first item value 
     * @param second will be set as the second integer value 
     */
    public void setSecond(int second) {
        this.second = second;
    }
    /**
     * get the value of the first integer
     * @return the first integer value
     */
    public int getFirst() {
        return first;
    }
    /**
     * get the value of the second integer
     * @return the second integer value
     */
    public int getSecond() {
        return second;
    }
}
