import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Random;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Data {
    /**
     * Generate random integer numbers and saves it into a text file
     * @param address the string address that the text file will be stored
     * @param numberOfEntries number of integer numbers that will be created in the text file
     * @throws IOException 
     */
    public static void generateData(String address, int numberOfEntries) throws IOException {
        try {
	    	long start = System.currentTimeMillis();
	        FileWriter fw = new FileWriter(address);
	        PrintWriter pw = new PrintWriter(fw);
	        
	        Random rand = new Random();
	        for (int i = 0; i < numberOfEntries; i++)
	            pw.println(rand.nextInt(Integer.MAX_VALUE) + 1);
	        pw.close();
	        long end = System.currentTimeMillis();
	        long elapsedTime = (end - start) / 1000 / 60;
	        System.out.printf("Time it took to write a %,d data set file was %d min\n ", numberOfEntries, elapsedTime);
        }
        catch (IOException ioe) {
        	throw new IOException("Not able to create a text file at specified location. Change the address!");
        }

    }
    
}
