import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.IOException;
import java.util.Random;
/**
 * 
 * @author Mohammadreza Ramzanpour
 */
public class Sort {
	
    /** Simple bubble sort algorithm */
    public static <E> void simpleBubbleSort(E[] data, Comparator<E> comp) {
        for (int j = 0; j < data.length; j++) { 
            for (int i = 0; i < data.length - 1; i++) {
                if ( comp.compare(data[i], data[i+1]) > 0 ) {
                    E temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                }
            }
        }
    }
	
    /** Selection sort algorithm */
    public static <E> void selectionSort(E[] data, Comparator<E> comp) {
        int minIndex;
        for (int i = 0; i < data.length; i++) {
            E temp = data[i];
            minIndex = i;
            for (int j = i + 1; j < data.length; j++) {
                if ( comp.compare(data[j], temp) < 0 ) {
                    temp = data[j];
                    minIndex = j;
                }
            }
            data[minIndex] = data[i];
            data[i] = temp;
        }
    }
    
    /** Insertion sort algorithm */
    public static <E> void insertionSort(E[] data, Comparator<E> comp) {
        int j;
        E temp;
        for (int i = 1; i < data.length; i++) {
            j = i;
            temp = data[i];
            
            while ( j != 0 && comp.compare(data[j-1], temp) > 0 ) {
                data[j] = data[j - 1];
                j--;
            }
            
            data[j] = temp;
        }
    }
    
    /** Merge sort algorithm */
    public static <E> void mergeSort (E[] s, Comparator<E> comp) {
        int n = s.length;
        if ( n < 2 )
            return;
        // divide
        int mid = n / 2;
        //E[] s1 = Arrays.copyOfRange(s, 0, mid);
        E[] s1 = copyInRange(s, 0, mid);
        //E[] s2 = Arrays.copyOfRange(s, mid, n);
        E[] s2 = copyInRange(s, mid, n);
        // conquer (with recursion)
        mergeSort(s1, comp);
        mergeSort(s2, comp);
        // merge results
        merge(s1, s2, s, comp);
    }
    
    /** private utility for merging sub-arrays, used in merge sort algorithm */
    private static <E> void merge(E[] s1, E[] s2, E[] s, Comparator<E> comp) {
        int i = 0, j = 0;
        while ( i + j < s.length ) {
            if ( j == s2.length || ( i < s1.length && comp.compare(s1[i], s2[j]) < 0 ) )
                s[i + j] = s1[i++];
            else
                s[i + j] = s2[j++];
        }
    }
    
    /**
     * 
     * @param <E> generic type of data
     * @param data array we want to copy from
     * @param start starting index to copy from
     * @param end ending index to copy from
     * @return the copied array from index start to index end
     */
    private static <E> E[] copyInRange(E[] data, int start, int end) {
        E[] duplicate = (E[]) new Object[end - start];
        for (int i = 0; i < end - start; i++) {
            duplicate[i] = data[start + i];
        }
        // data = null; // Can we uncomment this line??
        return duplicate;
    }
    
    /** Recursive quick sort algorithm for sorting between two specific indexes, used as private utility */
    private static <E> void quickSortInPlace(E[] s, Comparator<E> comp, int a, int b) {
        if ( a >= b )
            return;
        int left = a;
        int right = b - 1;
        E pivot = s[b];
        E temp;
        while (left <= right) {
            while (left <= right && comp.compare(s[left], pivot) < 0)
                left++;
            while (left <= right && comp.compare(s[right], pivot) > 0)
                right--;
            if (left <= right) {
                temp = s[left];
                s[left] = s[right];
                s[right] = temp;
                left++;
                right--;
            }
        }
        temp = s[left];
        s[left] = s[b];
        s[b] = temp;
        quickSortInPlace(s, comp, a, left - 1);
        quickSortInPlace(s, comp, left + 1, b);
        
    }
    
    /** Applying recursive quick sort algorithm to the whole array */
    public static <E> void quickSort(E[] data, Comparator<E> comp) {
        quickSortInPlace(data, comp, 0, data.length - 1);
    }
    
    /** Radix sort, taking 4 comparators as input */
    public static <E> void radixSort(E[] data, Comparator<E> comp1,  Comparator<E> comp2, Comparator<E> comp3, 
            Comparator<E> comp4) {
        Sort.mergeSort(data, comp4);
        Sort.mergeSort(data, comp3);
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
    
    /** Radix sort, taking three input comparators */
    public static <E> void radixSort(E[] data, Comparator<E> comp1, Comparator<E> comp2, Comparator<E> comp3) {
        Sort.mergeSort(data, comp3);
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
    
    /** Radix sort, taking two comparators as input */
    public static <E> void radixSort(E[] data, Comparator<E> comp1, Comparator<E> comp2) {
        Sort.mergeSort(data, comp2);
        Sort.mergeSort(data, comp1);
    }
    
    /**
     * External Merge Sort Algorithm
     * @param address the string address of the input file
     * @param output the string address of the output file, sorted values will be saved here
     * @throws IOException 
     */
    public static void externalMergeSort(String address, String output) 
    		throws IOException {
        File tempFile = new File(address);
        int maxUnitSize = memoryTest(5000000);
        System.out.printf("Maximum number of items that can be processed in RAM was approximately found "
    			+ "to be %,d item\n", maxUnitSize);
        IntegerComparator comp = new IntegerComparator();
        long startTime, endTime, startTotal, endTotal, blockTime, startAux = 0;
        
        startTotal = System.currentTimeMillis();
        startTime = System.currentTimeMillis();
        startAux = startTime;
        
        String tempAddress;
        ArrayList<String> addressList = new ArrayList<>();
        FileWriter fw;
        PrintWriter pw;
        Integer[] data = new Integer[maxUnitSize];
        File file = new File(address);
        Scanner sc = new Scanner(file);
        
        int count = 0;
        int n = 0;

        while(sc.hasNext()) {
            data[count] = sc.nextInt();
            count++;
            if (count == maxUnitSize) {
                Sort.mergeSort(data, comp);
                
                count = 0;
                //tempAddress = String.format("C:\\temp\\temp%d.txt", n);
                tempAddress = String.format("%s\\temp%d.txt", tempFile.getParent(), n);
                addressList.add(tempAddress);
                fw = new FileWriter(tempAddress);
                pw = new PrintWriter(fw);
                for (Integer i : data)
                    pw.println(i);
                pw.close();
                endTime = System.currentTimeMillis();
                blockTime = (endTime - startTime) / 1000;
                startTime = System.currentTimeMillis();
                startAux = startTime;
                System.out.printf("Time it takes to move block %d from hard disk into RAM and write it back to hard"
                		+ " drive with the size of %,d items is %,d seconds\n", (n+1), maxUnitSize, blockTime);
                n++;
            }
        }
        if (count != maxUnitSize && count != 0) {
            Integer[] temp = arrayCopyInRange(data, 0, count);
            Sort.mergeSort(temp, comp);
            tempAddress = String.format("%s\\temp%d.txt", tempFile.getParent(), n);
            addressList.add(tempAddress);
            fw = new FileWriter(tempAddress);
            pw = new PrintWriter(fw);
            for (Integer i : temp)
                pw.println(i);
            pw.close();
            endTime = System.currentTimeMillis();
            blockTime = (endTime - startAux) / 1000;
            System.out.printf("Time it takes to move block %d from hard disk into RAM and write it back to hard"
            		+ " drive with the size of %,d items is %,d seconds\n", (n+1), count, blockTime);
            n++;
        }
        int totalSize = 0;
        if (count != maxUnitSize && count != 0 )
            totalSize = (n - 1) * maxUnitSize + count;
        if (count == 0)
            totalSize = n * maxUnitSize;
        
        /** Creating n file, scanner */
        ArrayList<File> fileList = new ArrayList<>();
        ArrayList<Scanner> scannerList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            file = new File(addressList.get(i));
            fileList.add(file);
            sc = new Scanner(file);
            scannerList.add(sc);
        }
        /******************************************************/
        fw = new FileWriter(output);
        pw = new PrintWriter(fw);
        ArrayList<TwoValue> minSet = new ArrayList<>();
        TwoValue obj;
        for (int i = 0; i < n; i++) {
            if ( scannerList.get(i).hasNextInt() ) {
                int temp = scannerList.get(i).nextInt();
                obj = new TwoValue();
                obj.setFirst(temp);
                obj.setSecond(i);
                minSet.add(obj);
            }
        }
        TwoValue obj2;
        ArrayList<Integer> removeIndex = new ArrayList<>();
        for (int j = 0; j < totalSize; j++) {
            obj = new TwoValue();
            obj = minimumFinder(minSet, removeIndex);
//            obj.setSecond(indexModifier(obj.getSecond(), removeIndex));
            pw.println(obj.getFirst());
            if (scannerList.get(obj.getSecond()).hasNextInt()) {
                obj2 = new TwoValue();
                obj2.setFirst(scannerList.get(obj.getSecond()).nextInt());
                obj2.setSecond(obj.getSecond());
                /****************/
                minSet.set(obj.getSecond(), obj2);
            }
            else {
                //minSet.remove(obj.getSecond()); //Why can not use obj.getSecond()?
                removeIndex.add(obj.getSecond());
            }
            
        }
        pw.close();
        endTotal = System.currentTimeMillis();
        long totalElapsedTime = (endTotal - startTotal) / 1000 / 60;
        System.out.printf("Time it takes to sort the entire file is %d min\n", totalElapsedTime);
        
        /** Deleting temporary files */
        for (int i = 0; i < n; i++) {
            scannerList.get(i).close();
            fileList.get(i).delete();
        }
        
    }
    
    /** Finding the minimum value of paired value object and its index */
    private static TwoValue minimumFinder(ArrayList<TwoValue> list, ArrayList<Integer> removeList) {
        int sz = list.size();
        int s = 0;
        while (removeList.contains(s))
            s++;
        int min = list.get(s).getFirst();
        int index = s;
        for ( int i = s+1; i < sz; i++ ) {
            if (!removeList.contains(i)) {
                if ( list.get(i).getFirst() < min ) {
                    min = list.get(i).getFirst();
                    index = i;
                }
            }
        }
        return list.get(index);
    }
    
    /** Test how many Integer items can be fitted into RAM for sorting */
    private static int memoryTest(int size) {
        Random rand = new Random();
        IntegerComparator comp = new IntegerComparator();
        ArrayList<Integer> list = new ArrayList<>();
        try {
            while (true) {
                for (int i = 0; i < size / 2; i++)
                    list.add(rand.nextInt(Integer.MAX_VALUE));
                mergeSort(listToArray(list), comp);
                size *= 2;
            }
    	}
    	catch (OutOfMemoryError oome) {
    		return size / 2;
    	}
    }
    
    /**
     * Partially copy an array
     * @param data the source file
     * @param start start index for copying
     * @param end the final index of copying will be end - 1
     * @return the copied array
     */
    private static Integer[] arrayCopyInRange(Integer[] data, int start, int end) {
        Integer[] ans = new Integer[end - start];
        for (int i = start; i < end; i++) {
            ans[i - start] = data[i];
        }
        return ans;
    }
    
    /** Convert array list into array */
    private static Integer[] listToArray(ArrayList<Integer> data) {
        int sz = data.size();
        Integer[] ans = new Integer[sz];
        for (int i = 0; i < sz; i++)
            ans[i] = data.get(i);
        return ans;
    }
	
}
