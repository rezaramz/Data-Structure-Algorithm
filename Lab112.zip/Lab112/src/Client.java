import java.io.File;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author MReza
 */
public class Client {

    public static void main(String[] args) {

        String input = "C:\\data\\data.txt";
        String output = "C:\\data\\sortedData.txt";
        
        try {
            Data.generateData(input, 1000000000);
        }
        catch (IOException ioe) {
        	System.out.println(ioe.getMessage());
        	System.exit(1);
        }
        try {
            Sort.externalMergeSort(input, output);
        }
        catch (IOException ioe) {
           System.out.println("Specified input file does not exist");
           System.exit(1);
        }
        
        /** Printing the first 100 lines of data and sorted file */
        System.out.println("First 100 lines of the raw data file:");
        try {
	        File file = new File(input);
	        Scanner sc = new Scanner(file);
	        for (int i = 0; i < 100; i++)
	        	System.out.println(sc.nextInt());
	        sc.close();
	        
	        System.out.println("====================");
	        System.out.println("First 100 lines of the sorted file:");
	        file = new File(output);
	        sc = new Scanner(file);
	        for (int i = 0; i < 100; i++)
	        	System.out.println(sc.nextInt());
	        sc.close();
        }
        catch (Exception e) {
        	
        }
    	
    }
    
}