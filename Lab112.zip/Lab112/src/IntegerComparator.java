/**
 *
 * @author MReza
 */
public class IntegerComparator implements Comparator<Integer> {
    /**
     * comparator of the two Integer values
     * @param a first input
     * @param b second input
     * @return positive value if a > b, negative value if a < b and 0 if a = b
     */
    @Override
    public int compare(Integer a, Integer b) {
        if ( a == null || b == null ) {
            throw new NullPointerException("Null object in compare method");
        }
        return (a - b);
    }
}
