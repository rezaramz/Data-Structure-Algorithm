import java.util.Iterator;
import java.util.ArrayList;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        /** Building the tree using bottom-up approach */
        Position<String> temp;
        Position<String> temp2;
        
        LinkedBinaryTree<String> rightSubtree = new LinkedBinaryTree<>();
        temp = rightSubtree.addRoot("-");
        
        LinkedBinaryTree<String> t1 = new LinkedBinaryTree<>();
        temp2 = t1.addRoot("-");
        t1.addLeft(temp2, "7");
        t1.addRight(temp2, "2");
        
        LinkedBinaryTree<String> t2 = new LinkedBinaryTree<>();
        t2.addRoot("1");
        
        rightSubtree.attach(temp, t1, t2);
        //--------------------------------------------------------
        
        LinkedBinaryTree<String> t3 = new LinkedBinaryTree<>();
        temp = t3.addRoot("+");
        t3.addLeft(temp, "5");
        t3.addRight(temp, "2");
        
        LinkedBinaryTree<String> t4 = new LinkedBinaryTree<>();
        temp = t4.addRoot("-");
        t4.addLeft(temp, "2");
        t4.addRight(temp, "1");
        
        LinkedBinaryTree<String> t5 = new LinkedBinaryTree<>();
        temp = t5.addRoot("*");
        t5.attach(temp, t3, t4);
        
        //----------------------------------------------------
        
        LinkedBinaryTree<String> t6 = new LinkedBinaryTree<>();
        temp = t6.addRoot("+");
        t6.addLeft(temp, "2");
        t6.addRight(temp, "9");
        
        LinkedBinaryTree<String> t7 = new LinkedBinaryTree<>();
        temp = t7.addRoot("/");
        t7.attach(temp, t5, t6);
        
        LinkedBinaryTree<String> t8 = new LinkedBinaryTree<>();
        temp = t8.addRoot("+");
        t8.attach(temp, t7, rightSubtree);
        
        LinkedBinaryTree<String> mathTree = new LinkedBinaryTree<>();
        temp = mathTree.addRoot("*");
        LinkedBinaryTree<String> t9 = new LinkedBinaryTree<>();
        t9.addRoot("8");
        
        mathTree.attach(temp, t8, t9);
        // -------------------  Finished creating tree ------------------
        
        /** Printing the natural statement as stated (infix) */
        mathTree.printInorder(mathTree.root());
        System.out.println();
        
        /** Inorder traversal */
        Iterator<Position<String>> inorderIterator = mathTree.positions().iterator();
        System.out.println("Inorder representation:");
        while (inorderIterator.hasNext())
            System.out.print(inorderIterator.next().getElement() + " ");
        System.out.println();
        
        /** preorder traversal */
        System.out.println("Preorder presentation:");
        Iterator<Position<String>> preorderIterator = mathTree.preorder().iterator();
        while (preorderIterator.hasNext())
            System.out.print(preorderIterator.next().getElement() + " ");
        System.out.println();
        
        /** Postorder traversal */
        System.out.println("Postorder presentation:");
        Iterator<Position<String>> postorderIterator = mathTree.postorder().iterator();
        while (postorderIterator.hasNext())
            System.out.print(postorderIterator.next().getElement() + " ");
        System.out.println();
        
        /** Breadth-first traversal */
        System.out.println("Breadth-first:");
        Iterator<Position<String>> breadthfirstIterator = mathTree.breadthfirst().iterator();
        while (breadthfirstIterator.hasNext())
            System.out.print(breadthfirstIterator.next().getElement() + " ");
        System.out.println();
        
        /** Preorder indent presentation */
        System.out.println("preOrder indent:");
        printPreorderIndent(mathTree, temp, 6);
        
        /** Parenthesized presentation */
        System.out.println("Parenthesized:");
        parenthesize(mathTree, temp);
        System.out.println();
    }
    
    /** Prints preorder representation of subtree of T rooted at p having depth  d */
    public static <E> void printPreorderIndent(Tree<E> T, Position<E> p, int d) {
        System.out.println(spaces(2*d) + p.getElement());
        for (Position<E> c : T.children(p))
            printPreorderIndent(T, c, d+1);
    }
    
    /** Static method to create n spaces */
    protected static String spaces(int n) {
        String answer = "";
        for (int i = 0; i < n; i++)
            answer += " ";
        return answer;
    }
    
    /** prints labeled representation of subtree of T rooted at p having depth d. */
    public static <E> void printPreorderLabeled(Tree<E> T, Position<E> p, ArrayList<Integer> path) {
        int d = path.size();
        System.out.println(spaces(2*d));
        for (int j = 0; j < d; j++)
            System.out.println(path.get(j) + (j == d - 1 ? " " : "."));
        System.out.println(p.getElement());
        path.add(1);
        for (Position<E> c : T.children(p)) {
            printPreorderLabeled(T, c, path);
            path.set(d, 1 + path.get(d));
        }
        path.remove(d);
    }
    
    /** prints parenthesized representation of subtree of T rooted at p */
    public static <E> void parenthesize(Tree<E> T, Position<E> p) {
        System.out.print(p.getElement());
        if (T.isInternal(p)) {
            boolean firstTime = true;
            for (Position<E> c : T.children(p)) {
                System.out.print( (firstTime ? " (" : ", ") );
                firstTime = false;
                parenthesize(T, c);
            }
            System.out.print(")");
        }
    }
   
}
