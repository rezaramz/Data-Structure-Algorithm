/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface Queue<E> {
    /** returns number of elements in the queue */
    int size();
    /** Checks if the Queue is empty or not */
    boolean isEmpty();
    /** Inserts an element into the Queue */
    void enqueue(E e);
    /** Returns the first element of the Queue */
    E first();
    /** Removes the last element from the Queue */
    E dequeue();
}
