import java.util.Iterator;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public interface Tree<E> extends Iterable<E> {
    /** Gives the Position for the root of the tree */
    Position<E> root();
    /** Returns Position of the input Position p */
    Position<E> parent(Position<E> p) throws IllegalArgumentException;
    /** Returns an iterable collection of children of Position p */
    Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException;
    /** Returns number of children for given Position p */
    int numChildren(Position<E> p) throws IllegalArgumentException;
    /** Checks if the node is internal or not */
    boolean isInternal(Position<E> p) throws IllegalArgumentException;
    /** Checks if the node is external or not */
    boolean isExternal(Position<E> p) throws IllegalArgumentException;
    /** Checks if the node is root of the tree or not */
    boolean isRoot(Position<E> p) throws IllegalArgumentException;
    /** Returns number of elements stored in the tree */
    int size();
    /** Checks if the tree is empty or not */
    boolean isEmpty();
    /** Returns an itertor from the collection of elements */
    @Override
    Iterator<E> iterator();
    /** Returns an iterable collection */
    Iterable<Position<E>> positions();
}
