import java.util.Random;
/**
 * @version 1.0 09/12/2018
 * @author Mohammadreza Ramzanpour
 * @param <T> Generic type parameter
 */
public class ArrayBag<T> implements Bag<T> {
    /**
     * Array list which holds the items in the bag
     */
    private T[] list;
    /**
     * Keep track of the number of items in the bag
     */
    private int count;
    /**
     * Default constructor which creates a list with the initial length of 50, no element stored.
     */
    public ArrayBag() {
        list = (T[]) new Object[50];
        count = 0;
    }
    /**
     * Overloaded constructor that creates a list with the given initial capacity
     * @param initialCapacity defines an initial capacity(length) of the list
     */
    public ArrayBag(int initialCapacity) {
       list = (T[]) new Object[initialCapacity];
       count = 0;
    }
    /**
     * Gets the current size of the array
     * @return The number of elements stored in the array.
     */
    @Override
    public int getCurrentSize() {
        return count;
    }
    /**
     * Checks if the array is empty or not.
     * @return true if it is empty, false otherwise.
     */
    @Override
    public boolean isEmpty() {
        return count == 0;
    }
    /**
     * Adds an item to the end of the array.
     * @param item will be added to the array.
     */
    @Override
    public void add(T item) {
        if (count == list.length) {
            T[] temp = (T[]) new Object[2 * count];
            for (int i = 0; i < count; i++)
                temp[i] = list[i];
            list = temp;
            temp = null;
            list[count++] = item;
        }
        else {
            list[count++] = item;
        }
    }
    /**
     * Removes a random object from the array.
     * @return the removed element.
     */
    @Override
    public T remove() {
        if (isEmpty())
            return null;
        Random randObj = new Random();
        int randIndex = randObj.nextInt(count);
        T removedElement = list[randIndex];
        for (int i = randIndex; i < count-1; i++)
            list[i] = list[i+1];
        count--;
        return removedElement;
    }
    /**
     * removes a specific item from the array.
     * @param item is the element which is going to be removed from the array.
     * @return true if the item exists in array and removed, false otherwise.
     */
    @Override
    public boolean remove(T item) {
        int index = count;
        for (int i = 0; i < count; i++) {
            if (list[i].equals(item)) {
                index = i;
                break;
            }
        }
        if (index == count)
            return false;
        for (int i = index; i < count-1; i++)
            list[i] = list[i+1];
        count--;
        return true;
    }
    /**
     * Clear all the contents from the array.
     */
    @Override
    public void clear() {
        count = 0;
    }
    /**
     * Gets the occurrence frequency of a specific item in the array.
     * @param item is checked for the number of repetition in the array.
     * @return the number of repetition in the array.
     */
    @Override
    public int getFrequencyOf(T item) {
        int freq = 0;
        for (int i = 0; i < count; i++) {
            if (list[i].equals(item))
                freq++;
        }
        return freq;
    }
    /**
     * Check if a specific element exists in the array or not.
     * @param item is checked for existance in the array.
     * @return true if the element exists in the array, false otherwise.
     */
    @Override
    public boolean contains(T item) {
        for (int i = 0; i < count; i++) {
            if (list[i].equals(item))
                    return true;
        }
        return false;
    }
    /**
     * String details of the array.
     * @return the String details.
     */
    @Override
    public String toString() {
        String temp = "[ ";
        for (int i = 0; i < count; i++) {
            temp += list[i].toString();
            if (i != count - 1)
                temp += ", ";
        }
        temp += " ]";
        return temp;
    }
    /**
     * Checks the equivalency of two objects
     * @param obj is checked for equivalency.
     * @return true if equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ArrayBag == false)
            return false;
        ArrayBag o = (ArrayBag) obj;
        if (o.count != count)
            return false;
        for (int i = 0; i < count; i++) {
            if (o.get(i) != list[i])
                return false;
        }
        return true;
    }
    /**
     * Obtain the element stored in the index of the array
     * @param index, the index number of the array.
     * @return the element stored in the index number specified.
     */
    public T get(int index) throws ArrayIndexOutOfBoundsException {
        if (index >= count || index < 0)
            throw new ArrayIndexOutOfBoundsException("Specified index is out of bounds.");
        return list[index];
    }
}
