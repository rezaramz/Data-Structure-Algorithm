import java.io.File;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.io.FileNotFoundException;
/**
 *
 * @author Mohammadreza Ramzanpour
 * @version 09/27/18
 */
public class Client {
    /**
     * main method. Calls mainMenu() method
     * @param args 
     */
    public static void main(String[] args) {
        String s = "1";
//        System.out.println(s instanceof Integer);
        mainMenu();
    }
    
    /**
     * Displays main menu and process the input for calling appropriate method
     */
    public static void mainMenu() {
        String mainMenuDialogText = "Enter your choice:\nH: Harmonic sum\nI: Isabel sum\nL: List of files and folders"
                + "\nX: Exit";
        String mainMenuChoice = JOptionPane.showInputDialog(null, mainMenuDialogText);
        if (mainMenuChoice != null) {
            switch (mainMenuChoice) {
                case "h":
                case "H":
                    harmonicProcess();
                    break;
                case "i":
                case "I":
                    isabelProcess();
                    break;
                case "l":
                case "L":
                    listProcess();
                    break;
                case "x":
                case "X":
                    exitMenu();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Not valid option. Please try again.");
                    mainMenu();
            }
        }
        else
            exitMenu();
    }
    
    /**
     * Brings up the harmonic sum menu and process the user input
     */
    public static void harmonicProcess() {
        String input = JOptionPane.showInputDialog(null, "Enter an integer number:");
        if (input == null) 
            mainMenu();
        else {
            try {
                int n = Integer.parseInt(input);
                if (n <= 0) 
                    throw new IllegalArgumentException("Integer must be greater than zero for harmonic number.");
                System.out.println("Harmonic number of " + n + " : " + Recursion.harmonicSum(n));
                char continueChoice = continueProcess();
                if (continueChoice == 'y') // Yes
                    harmonicProcess();
                else
                    mainMenu();
            }
            catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(null, "Invalid integer/choice. Try again.");
                harmonicProcess();
            }
            catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                harmonicProcess();
            }
            catch (StackOverflowError soe) {
                JOptionPane.showMessageDialog(null, "Number is too large. StackOverflow error. Try smaller number.");
                harmonicProcess();
            }
        }
    }
    
    /**
     * Brings on the list menu and process the user input
     */
    public static void listProcess() {
        String path = JOptionPane.showInputDialog(null, "Enter a directory path:");
        if (path == null)
            mainMenu();
        else {
            try {
                File dir = new File(path);
                if (dir.exists() == false)
                    throw new IllegalArgumentException("Specified directory does not exist!");
                else if (!dir.isDirectory())
                    throw new IllegalArgumentException("Not an address of a directory!");
                else {
                    System.out.println("List Algorithm: list of files and directories in " + path);
                    Recursion.list(path);
                    char continueChoice = continueProcess();
                    if (continueChoice == 'y')
                        listProcess();
                    else
                        mainMenu();
                }
            }
            catch(IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                listProcess();
            }
            catch(NullPointerException npe) {
                JOptionPane.showMessageDialog(null, "Access to the specified directory denied. Try another directory!");
                listProcess();
            }
        }
    }
    
    /**
     * Brings on the Isabel sum menu and process the user input
     */
    public static void isabelProcess () {
        String path = JOptionPane.showInputDialog(null, "Enter your text file path here:");
        if (path == null)
            mainMenu();
        else {
            try {
                File fileObj = new File(path);
                if (!fileObj.exists() || fileObj.isDirectory())
                    throw new FileNotFoundException("No file found at the given path!");
                Scanner sc = new Scanner(fileObj);
                int i;
                ArrayBag<Integer> list = new ArrayBag<>();
                boolean isChanged = false;
                while (sc.hasNext()) {
                    if (sc.hasNextInt()) {
                        i = sc.nextInt();
                        list.add(i);
                    }
                    else {
                        sc.next();
                        isChanged = true;
                    }
                }

                int[] answer = new int[list.getCurrentSize()];
                for (int j = 0; j < list.getCurrentSize(); j++)
                    answer[j] = list.get(j);

                if (!isChanged)
                    System.out.println("Isabel Alg: Sum of integers in text file @ " + path + " is: " 
                            + Recursion.isabelSum(answer));
                else {
                    System.out.println("Input file was modified to ignore non-integer values."
                            + "Integer content is as the following:");
                    for (int q = 0; q < answer.length; q++)
                        System.out.print(answer[q] + "  ");
                    System.out.println("\nIsabel Alg: Sum of integers in modified text file @ " + path + " is: " + 
                            Recursion.isabelSum(answer));
                }    
                char continueChoice = continueProcess();
                if (continueChoice == 'y')
                    isabelProcess();
                else
                    mainMenu();
            }
            catch (IllegalArgumentException iae) {
                String temp = iae.getMessage();
                JOptionPane.showMessageDialog(null, "@" + path + " : " + temp);
                isabelProcess();
            }
            catch (FileNotFoundException fnfe) {
                JOptionPane.showMessageDialog(null, fnfe.getMessage());
                isabelProcess();
            }
            catch(OutOfMemoryError oome) {
                JOptionPane.showMessageDialog(null, "Input file too large for memory. "
                        + "Please try another file or reduce its size.");
                isabelProcess();
            }
        }
    }

    /**
     * Brings on the Continue menu
     * @return char 'y' if user press YES, char 'n' if user press NO
     */
    public static char continueProcess() {
        int exitChoice = JOptionPane.showConfirmDialog(null, "Do you want to continue with another run?!"
                , "Select an option", JOptionPane.YES_NO_OPTION);
        if (exitChoice == 0)
            return 'y';
        else
            return 'n';
    }
    
    /**
     * Brings on the exit menu
     */
    public static void exitMenu() {
        int exitChoice = JOptionPane.showConfirmDialog(null, "Are you sure?!", "Select an option", JOptionPane.YES_NO_OPTION);
        if (exitChoice == 0)
            System.exit(0);
        else
            mainMenu();
    }
       
}