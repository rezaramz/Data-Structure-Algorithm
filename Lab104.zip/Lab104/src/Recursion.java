import java.io.File;
/**
 *
 * @author Mohammadreza Ramzanpour
 * @version 09/27/2018
 */
public class Recursion {
    
    /**
     * lists all the subentries including files and folders of a specific path 
     * @param path the path of the directory 
     */
    public static void list(String path) {
        File fileObj = new File(path);
        if (fileObj.isDirectory() == false)
            throw new IllegalArgumentException("Not address of a directory");
        for(String temp : fileObj.list()) {
            File subEntry = new File(fileObj, temp);
            if (subEntry.isDirectory() == false) {
                System.out.println("File: " + subEntry.getPath());
            }
            else {
                System.out.println("Directory: " + subEntry.getPath());
                list(subEntry.getPath());
            }
        }
    }
    
    /**
     * Calculates a harmonic number of an integer greater than zero
     * @param k integer that harmonic number is calculated
     * @return double, the harmonic number
     */
    public static double harmonicSum(int k) {
        if (k == 1)
            return 1.0;
        return (1.0 / k) + harmonicSum(k - 1);
    }
    
    /**
     * calculates the summation of array of integers
     * @param list the array which the summation is performed on.
     * @return the summation of the integers in the array.
     * @throws IllegalArgumentException If number of integers in the array is not exponential of 2
     */
    public static int isabelSum(int[] list) throws IllegalArgumentException {
        if (isExpOfTwo(list.length) == false)
            throw new IllegalArgumentException("Size of the list must be a power of two");
        if (list.length == 1)
            return list[0];
        int[] temp = new int[list.length / 2];
        for (int i = 0; i < temp.length; i++) {
            temp[i] = list[2*i] + list[2*i+1];
        }
        list = temp;
        temp = null;
        return isabelSum(list);
    }
    
    /**
     * Indicates if a specific number is exponential of 2 or not.
     * @param n the input of the method which is checked for being exponential of 2
     * @return true if exponential of 2, false otherwise
     * @throws IllegalArgumentException if empty text file is given
     */
    private static boolean isExpOfTwo(int n) throws IllegalArgumentException{
        if (n <= 0)
            //throw new IllegalArgumentException("Integer must be greater than zero");
            throw new IllegalArgumentException("Empty text file");
        if (n % 2 == 1 && n != 1)
            return false;
        if (n == 1)
            return true;
        return isExpOfTwo(n / 2);
    }
}
