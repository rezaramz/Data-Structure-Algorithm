import java.util.Random;
/**
 *
 * @author Mohammadreza Ramzanpour
 * @version 10/01/2018
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Begin testing add time of Array List\n");
        testArrayList();
        System.out.println("\nEnd testing add time of Array List\n");
        
        System.out.println("Test ArrayStack");
        Stack<Integer> s = new ArrayStack<>(2);
        testStack(s);
        System.out.println("Test ArrayStack finished\n");
        
        System.out.println("Test LinkedStack");
        s = new LinkedStack<>();
        testStack(s);
        System.out.println("Test LinkedStack finished\n");
        
        System.out.println("Test ArrayQueue");
        Queue<Integer> q = new ArrayQueue<>(3);
        testQueue(q);
        System.out.println("Test ArrayQueue finished\n");
        
        System.out.println("Test LinkedQueue");
        q = new LinkedQueue<>();
        testQueue(q);
        System.out.println("Test LinkedQueue finished");
    }
    
    /**
     * Test the ArrayStack and LinkedStack
     * @param s takes the class types implemented from Stack interface
     */
    public static void testStack(Stack s) {
        s.push(8);
        s.push(-1);
        System.out.println("size: " + s.size());
        s.pop();
        s.pop();
        System.out.println("Size after popping off all elements: " + s.size());
        s.push(12);
        System.out.println(s.pop());
        System.out.println(s.size());
        s.push(12);
        s.push(13); // exception happens at this point
    }
    
    /**
     * Tests the ArrayQueue and LinkedQueue
     * @param q takes the class types implemented from Queue interface
     */
    public static void testQueue(Queue q) {
        q.enqueue(5);
        q.enqueue(2);
        q.enqueue(4);
        System.out.println(q.size());
        System.out.println("Dequeued item: " + q.dequeue());
        System.out.println(q.isEmpty());
    }
    
    /**
     * Test the add time of the ArrayList
     */
    public static void testArrayList() {
        int fillIndex = 134217728 / 8;
        loop: while (true) {
            try {
                fillIndex = 2 * fillIndex;
                ArrayList<Boolean> list = new ArrayList<>(1024);
                Random randObj = new Random();
                for (int i = 0; i < fillIndex - 4; i++)
                    list.add(i, randObj.nextBoolean());
                System.out.printf("======= n = %d ========\n", fillIndex);
             
                for (int iterator = 0; iterator < 10; iterator++) {
                    long startTime = System.nanoTime();
                    list.add(fillIndex + iterator - 4, randObj.nextBoolean());
                    long endTime = System.nanoTime();
                    System.out.printf("%d: Time: %d nsec\n", list.size(), endTime - startTime);
                }
                System.out.println("======= Finished ======");
            }
            catch (OutOfMemoryError oome) {
                System.out.printf("Ran out of Memory!");
                break loop;
            }
        }
    }
    
}
