/**
 * 
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        String[] listOfWords = {"POTS", "STOP", "TOPS"};
        int[] hashString = new int[listOfWords.length];
        System.out.println("Summary hash code information:");
        for (int i = 0; i < listOfWords.length; i++) {
            hashString[i] = hashCode(listOfWords[i]);
            System.out.printf("%-6s: %s\n", listOfWords[i], addZero(Integer.toBinaryString(hashString[i])));
        }
        System.out.println("============================================");
        for (String s : listOfWords) {
            verbalHashCode(s);
            System.out.println();
        }
    }
    
    /** Cyclic shift hashCode written in the book */
    public static int hashCode(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) {
            h = (h << 5) | (h >>> 27);
            h += (int) s.charAt(i);
        }
        return h;
    }
	
    public static void verbalHashCode(String s) {
        
        System.out.printf("Creating hash code for %-10s\n", s);
        int h = 0;
        for (int i = 0; i < s.length(); i++) {    
            System.out.printf("%-40s\t%s\n", "Entering hashcode, pass " + i, addZero(Integer.toBinaryString(h)));
            System.out.printf("%-40s\t%s\n", "hashCode << 5", addZero(Integer.toBinaryString(h << 5)));
            System.out.printf("%-40s\t%s\n", "hashCode >>> 27", addZero(Integer.toBinaryString(h >>> 27)));
            System.out.printf("%-40s\t%s\n", "hashCode << 5 | hashCode >>> 27", 
                    addZero(Integer.toBinaryString( h = (h << 5) | (h >>> 27) )));
            System.out.printf("%-40s\t%s\n", "Adding character " + s.charAt(i), 
                    addZero(Integer.toBinaryString((int)s.charAt(i))));
            h += (int) s.charAt(i);
            System.out.printf("%-40s\t%s\n", "Exiting hashCode", addZero(Integer.toBinaryString(h)));
        }
            System.out.printf("%-40s\t%s\n", "hash code for " + s + " is ", addZero(Integer.toBinaryString(h)));
    }
    
    /** Adds zero to the binary string to form a 32 bit binary string representation */
    private static String addZero (String s) {
        if (s.length() == 32)
            return s;
        int num = 32 - s.length();
        String answer = "";
        for (int i = 0; i < num; i++)
            answer += "0";
        answer += s;
        return answer;
    }

}
