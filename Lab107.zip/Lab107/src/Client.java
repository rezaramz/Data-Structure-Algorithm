/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class Client {

    public static void main(String[] args) {
        int count = 0;
        LuckyNumberList list = new LuckyNumberList();
        LuckyNumber[] ln = new LuckyNumber[10];
        String[] names = {"Mary", "Melissa", "Joseph", "Rachel", "Tom", "John", "Paul", "Mariah", "Moses", "Mathew"};
        
        
        for (String name : names) {
            ln[count] = new LuckyNumber(name);
            list.addLuckyNumber(ln[count]);
            count++;
        }
        LuckyNumber temp;
        String evenText;
        String primeText;
        System.out.println("========== Displaying 10 inserted item ============");
        Iterator<Position<LuckyNumber>> it = list.defaultPosition().iterator();
        while (it.hasNext()) {
            temp = it.next().getElement();
            if ( isEven(temp.getLuckyNumber()) )
                evenText = "Even";
            else
                evenText = "Odd";
            if ( isPrime(temp.getLuckyNumber()) )
                primeText = "Prime";
            else
                primeText = "Not Prime";
            System.out.printf("Name: %-7s\tLuckyNumber: %d\t%-5s\t%-10s\n", temp.getName(), temp.getLuckyNumber(),
                    evenText, primeText);
        }
        System.out.println("============== End of displaying inserted items =============\n");
        
        System.out.println("========= Even numbers ===========");
        it = list.evenPosition().iterator();
        while (it.hasNext()) {
            temp = it.next().getElement();
            if ( isEven(temp.getLuckyNumber()) )
                evenText = "Even";
            else
                evenText = "Odd";
            if ( isPrime(temp.getLuckyNumber()) )
                primeText = "Prime";
            else
                primeText = "Not Prime";
            System.out.printf("Name: %-7s\tLuckyNumber: %d\t%-5s\t%-10s\n", temp.getName(), temp.getLuckyNumber(),
                    evenText, primeText);
        }
        
        System.out.println("============== Prime numbers ==============");
        it = list.primePosition().iterator();
        while (it.hasNext()) {
            temp = it.next().getElement();
            if ( isEven(temp.getLuckyNumber()) )
                evenText = "Even";
            else
                evenText = "Odd";
            if ( isPrime(temp.getLuckyNumber()) )
                primeText = "Prime";
            else
                primeText = "Not Prime";
            System.out.printf("Name: %-7s\tLuckyNumber: %d\t%-5s\t%-10s\n", temp.getName(), temp.getLuckyNumber(),
                    evenText, primeText);
        }
        System.out.println("==========================");
    }
    
    /**
     * Checks if an integer number is even or not
     * @param n is tested for being even integer
     * @return true if integer number is even, false otherwise
     */
    private static boolean isEven(int n) {
        return ( n % 2 == 0);
    }
    /**
     * Checks if an integer number is prime number or not
     * @param n will be tested to check if it is prime or not
     * @return true if the integer is prime, false otherwise
     */
    private static boolean isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i < n; i++) {
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
