import java.util.Random;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class LuckyNumber {
    private String name;
    private int luckyNumber;
    /**
     * Overloaded constructor
     * @param name will be set as name in the LuckyNumber
     */
    public LuckyNumber(String name) {
        this.name = name;
        Random rand = new Random();
        this.luckyNumber = rand.nextInt(10);      
    }
    /**
     * Obtain the name of the LuckyNumber instance
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * Find the random number stored in the LuckyNumber
     * @return its random number
     */
    public int getLuckyNumber() {
        return luckyNumber;
    }
    /**
     * String representation of the LuckyNumber
     * @return string values of it
     */
    @Override
    public String toString() {
        String answer = "";
        answer += getClass().getName() + " Name: " + name + " LuckyNumber: " + luckyNumber;
        return answer;
    }
    /**
     * Checks for equality between LuckyNumber
     * @param obj will be tested for equality
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof LuckyNumber == false)
            return false;
        LuckyNumber o = (LuckyNumber) obj;
        return ( (o.name.equals(name)) && (o.luckyNumber == luckyNumber) );
    }
}
