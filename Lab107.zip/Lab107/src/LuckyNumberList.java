import java.util.NoSuchElementException;
/**
 *
 * @author Mohammadreza Ramzanpour
 */
public class LuckyNumberList {
    private LinkedPositionalList<LuckyNumber> list;
    /**
     * Default constructor. creates an empty LinkedPositionalList.
     */
    public LuckyNumberList() {
        list = new LinkedPositionalList<>();
    }
    /**
     * Add the LuckyNumber instance to the end of the list
     * @param ln will be added to the list
     */
    public void addLuckyNumber(LuckyNumber ln) {
        list.addLast(ln);
    }
    
    // nested EvenNumberIterator class
    private class EvenNumberIterator implements Iterator<Position<LuckyNumber>> {
        private Position<LuckyNumber> cursor = list.first(); // list.first();
        private Position<LuckyNumber> recent = null;
        
        @Override
        public boolean hasNext() {
            return (cursor != null);
        }
        
        @Override
        public Position<LuckyNumber> next() throws NoSuchElementException {
            if (recent == null) { //First iteration
                while (cursor != null && cursor.getElement().getLuckyNumber() % 2 != 0) {
                    cursor = list.after(cursor);
                }
            }
            if (cursor == null) throw new NoSuchElementException("nothing left in the list");
            recent = cursor;
            cursor = list.after(cursor);
            
            while (cursor != null && cursor.getElement().getLuckyNumber() % 2 != 0)
                cursor = list.after(cursor);
            return recent;
        }
        
        @Override
        public void remove() throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            list.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
    }
    // end of nested EvenNumberIterator class
    
    //----- nested PositionIterable class -----
    private class EvenNumberIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new EvenNumberIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    public Iterable<Position<LuckyNumber>> evenPosition() {
        return new EvenNumberIterable();
    }
    
    
    // nested PrimeNumberIterator class
    private class PrimeNumberIterator implements Iterator<Position<LuckyNumber>> {
        private Position<LuckyNumber> cursor = list.first(); // list.first();
        private Position<LuckyNumber> recent = null;
        
        private boolean isPrime(int n) {
            if (n <= 1)
                return false;
            for (int i = 2; i < n; i++) {
                if (n % i == 0)
                    return false;
            }
            return true;
        }
        
        @Override
        public boolean hasNext() {
            return (cursor != null);
        }
        
        @Override
        public Position<LuckyNumber> next() throws NoSuchElementException {
            if (recent == null) { //First iteration
                while ( cursor != null && !isPrime(cursor.getElement().getLuckyNumber()) ) {
                    cursor = list.after(cursor);
                }
            }
            if (cursor == null) throw new NoSuchElementException("nothing left in the list");
            recent = cursor;
            cursor = list.after(cursor);
            
            while (cursor != null && !isPrime(cursor.getElement().getLuckyNumber()))
                cursor = list.after(cursor);
            return recent;
        }
        
        @Override
        public void remove() throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            list.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
    }
    // end of nested PrimeNumberIterator class
    
    //----- nested PositionIterable class -----
    private class PrimeNumberIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new PrimeNumberIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    public Iterable<Position<LuckyNumber>> primePosition() {
        return new PrimeNumberIterable();
    }
    
    // nested PrimeNumberIterator class
    private class DefaultIterator implements Iterator<Position<LuckyNumber>> {
        private Position<LuckyNumber> cursor = list.first(); // list.first();
        private Position<LuckyNumber> recent = null;
        
        @Override
        public boolean hasNext() {
            return (cursor != null);
        }
        
        @Override
        public Position<LuckyNumber> next() throws NoSuchElementException {
            if (cursor == null)
                throw new NoSuchElementException("nothing left");
            recent = cursor;
            cursor = list.after(cursor);
            return recent;
        }
        
        @Override
        public void remove() throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            list.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
    }
    // end of nested PrimeNumberIterator class
    
    //----- nested PositionIterable class -----
    private class DefaultIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new DefaultIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    public Iterable<Position<LuckyNumber>> defaultPosition() {
        return new DefaultIterable();
    }
    
}
