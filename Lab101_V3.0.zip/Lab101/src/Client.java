import java.util.Scanner;
/**
 * @version 3.0
 * @author Mohammadreza Ramzanpour
 */
public class Client {
    
    /**
     * Enables clients to enter information of their employee
     * @param args
     */
    public static void main(String[] args)  {
        //List of variables
        Salaried tempSalaried;
        Hourly tempHourly;
        
        Employee[] employeeList = new Employee[10];
        for (int i = 0; i < 10; i++) {employeeList[i] = new Employee();}
        
        Scanner input = new Scanner(System.in);
        
        forLoop: for (int i = 0; i < 10; i++) {
            System.out.print("Enter your choice: s for Salaried / h for Hourly / q to quit: ");
            String choice = input.next();
            switch (choice) {
                case "h":
                    employeeList[i] = new Hourly();
                    tempHourly = (Hourly) employeeList[i];
                    
                    System.out.print("ID: ");
                    tempHourly.setId(input.nextInt());
                    System.out.print("Name: ");
                    tempHourly.setName(input.next());
                    System.out.print("Position: ");
                    tempHourly.setPosition(input.next());
                    System.out.print("Hourly rate: ");
                    tempHourly.setHourlyRate(input.nextDouble());
                    break;
                    
                case "s":
                    employeeList[i] = new Salaried();
                    tempSalaried = (Salaried) employeeList[i];
                    System.out.print("ID: ");
                    tempSalaried.setId(input.nextInt());
                    System.out.print("Name: ");
                    tempSalaried.setName(input.next());
                    System.out.print("Title: ");
                    tempSalaried.setTitle(input.next());
                    System.out.print("Salary: ");
                    tempSalaried.setSalary(input.nextInt());
                    break;
                default:
                    System.out.println("Entering data for employess are completed.");
                    break forLoop;
            }
        }
        
        //Printing details including blank ones
        for (int i = 0; i < 10; i++) {
            if (employeeList[i] instanceof Hourly) {
                Hourly.incrementHourlyCount();
            }
            else if (employeeList[i] instanceof Salaried) {
                Salaried.incrementSalariedCount();
            }
        }
        
        System.out.println("");
        System.out.println("Number of hourly workers: " + Hourly.getHourlyCount());
        System.out.println("Number of salaried workers: " + Salaried.getSalariedCount());
        
        System.out.println("");
        System.out.println("The details of the workers are:");
        for (int i = 0; i < 10; i++) {
            System.out.println(employeeList[i].toString());
        }
        
        //Give a raise of 10% to everyone
        for (int i = 0; i < 10; i++) {
            if (employeeList[i] instanceof Salaried) {
                tempSalaried = (Salaried) employeeList[i];
                tempSalaried.setSalary( (int) (1.1 * tempSalaried.getSalary()) );
            }
            else if (employeeList[i] instanceof Hourly) {
                tempHourly = (Hourly) employeeList[i];
                tempHourly.setHourlyRate( 1.1 * tempHourly.getHourlyRate());
            }
        }
        
        //Printing the non-blank entries after payment rise
        System.out.println("");
        System.out.println("10% raise was successfuly applied.");
        System.out.println("The details of the workers after 10% payment increase are as follows: ");
        for (int i = 0; i < 10; i++) {
            if (employeeList[i] instanceof Salaried || employeeList[i] instanceof Hourly) {
                System.out.println(employeeList[i].toString());
            }
        }
        
        //Explicitly testing the equals method
        Hourly hw1 = new Hourly(1, "Smith", "Programmer", 22);
        Salaried sw1 = new Salaried(1, "Paul", "Boss", 100000);
        Hourly hw2 = new Hourly(1, "Smith", "Programmer", 22);
        
        System.out.println("***Testing equals methods***");
        System.out.println("Is hourly worker1 equals to hourly worker2? " + hw1.equals(hw2));
        System.out.println("Is hourly worker1 equals to salaried worker1? " + hw1.equals(sw1));
    
    }
    
}