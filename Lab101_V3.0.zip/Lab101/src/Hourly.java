/**
 * @version 3.0
 * @author Mohammadreza Ramzanpour
 */
public class Hourly extends Employee {
    //Instance variables specific to Hourly class
    private String position;
    private double hourlyRate;
    private static int hourlyCount;
    
    //Constructors
    /**
     * Overload constructor. Create an instance of Hourly class with the given parameters
     * @param id
     * @param name
     * @param position
     * @param hourlyRate 
     */
    public Hourly(int id, String name, String position, double hourlyRate) {
        super(id, name);
        this.position = position;
        this.hourlyRate = hourlyRate;
    }
    
    /**
     * Default constructor of Hourly class
     */
    public Hourly() {
        super(0, null);
        this.position = null;
        this.hourlyRate = 0.0;
    }
    
    //Setter methods
    /**
     * set the position of hourly employee
     * @param position 
     */
    public void setPosition(String position) {this.position = position;}
    /**
     * set the hourly rate payment of the hourly employee
     * @param hourlyRate 
     */
    public void setHourlyRate(double hourlyRate) {this.hourlyRate = hourlyRate;}
    
    //Getter methods
    /**
     * 
     * @return position of hourly employee
     */
    public String getPosition() {return position;}
    /**
     * 
     * @return The hourly rate income of the hourly employee
     */
    public double getHourlyRate() {return hourlyRate;}
    
    /**
     * Compares an object with the reference variable of Hourly class
     * @param obj
     * @return true if equal, false otherwise
     */
    /**
     * Compare an object with the reference variable of an Hourly class
     * @param obj
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Hourly == false)
            return false;
        Hourly hourly = (Hourly) obj;
        return (super.equals(obj) && this.position.equals(hourly.position)
                && Math.abs(hourly.hourlyRate - this.hourlyRate) < 0.01);
    }
    
    /**
     * 
     * @return the string details of the hourly employee
     */
    @Override
    public String toString() {
        return (super.toString() + " Position: " + position
            + " Hourly rate: " + hourlyRate);
    }
    
    /**
     * Add one to the iterator of Hourly class
     */
    public static void incrementHourlyCount() {hourlyCount++;}
    /**
     * 
     * @return The value of the Hourly class iterator
     */
    public static int getHourlyCount() {return hourlyCount;}
  
}
