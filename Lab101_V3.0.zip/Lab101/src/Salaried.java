/**
 * @version 3.0
 * @author Mohammadreza Ramzanpour
 */
public class Salaried extends Employee {
    //Instance variable specific to Salaried class
    private String title;
    private int salary;
    private static int salariedCount;
    
    //Constructors
    /**
     * Overload constructor of the Salaried class with the given parameters
     * @param id
     * @param name
     * @param title
     * @param salary
     */
    public Salaried(int id, String name, String title, int salary) {
        super(id, name);
        this.title = title;
        this.salary = salary;
    }
    
    /**
     * create a Salaried instance with default values
     */
    public Salaried() {
        super(0, null);
        this.title = null;
        this.salary = 0;
    }
    
    //Setter methods
    /**
     * set the title of the salaried employee
     * @param title 
     */
    public void setTitle(String title) {this.title = title;}
    /**
     * set the salary of salaried employee
     * @param salary 
     */
    public void setSalary(int salary) {this.salary = salary;}
    
    //Getter methods
    /**
     * 
     * @return title of the salaried employee
     */
    public String getTitle() {return title;}
    /**
     * 
     * @return salary of the salaried employee
     */
    public int getSalary() {return salary;}
    
    //equals method
    /**
     * Compares two objects
     * @param obj
     * @return true if equal / false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Salaried == false)
            return false;
        Salaried sal = (Salaried) obj;
        return ( super.equals(obj) && title.equals(sal.title) && sal.salary == salary );
    }
    
    /**
     *
     * @return the details of the salaried employee
     */
    @Override
    public String toString() {
        return (super.toString() + " Title: " + title
                + " Salary: " + salary);
    }
    
    /**
     * Add one to the iterator of Salaried class
     */
    public static void incrementSalariedCount() {salariedCount++;}
    /**
     * 
     * @return The value of Salaried class iterator
     */
    public static int getSalariedCount() {return salariedCount;}
    
}
