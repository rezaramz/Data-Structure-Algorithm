/**
 * @version 3.0
 * @author Mohammadreza Ramzanpour
 */
public class Employee {
    
    // Instance variables common to both Salaried and Hourly
    protected int id;
    protected String name;
    
    //Constructors
    /**
     * Overload constructor, create an instance of the employee with the given parameters
     * @param id
     * @param name 
     */
    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    /**
     * Default constructors, set the values of id = 0, name = null
     */
    public Employee() {
        this(0, null);
    }
    
    //Setter methods
    /**
     * set the ID of the employee
     * @param id 
     */
    public void setId(int id) {this.id = id;}
    /**
     * set the name
     * @param name 
     */
    public void setName(String name) {this.name = name;}
    
    //Getter methods
    /**
     * 
     * @return id of the employee
     */
    public int getId() {return id;}
    /**
     * 
     * @return name of the employee
     */
    public String getName() {return name;}
    
    //equals method
    /**
     * Compare two reference variables
     * @param obj
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Employee == false)
            return false;
        Employee emp = (Employee) obj;
        return (emp.id == id && name.equals(emp.name));
    }
    
    /**
     * 
     * @return The string details of the Employee worker including ID and name
     */
    @Override
    public String toString() {
        return (getClass().getName() + " ID: " + id + " Name: " + name);
    }
}
